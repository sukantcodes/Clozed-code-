# 01. Matrix Digital Rain Animation (Terminal)
# Run in terminal and press Ctrl+C to stop!
import random, time, shutil

cols = shutil.get_terminal_size().columns
drops = [random.randint(-20, 0) for _ in range(cols)]
chars = "01ABCDEFGHIJKLMNOPQRSTUVWXYZ#$%&*@"

try:
    while True:
        line = ""
        for i in range(cols):
            if drops[i] > 0:
                line += f"\033[92m{random.choice(chars)}\033[0m"
            else:
                line += " "
            drops[i] += 1
            if drops[i] > random.randint(15, 35):
                drops[i] = random.randint(-15, 0)
        print(line)
        time.sleep(0.05)
except KeyboardInterrupt:
    print("\nMatrix exited.")
