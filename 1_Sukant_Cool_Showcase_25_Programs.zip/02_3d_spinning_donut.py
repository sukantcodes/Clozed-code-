# 02. 3D Spinning ASCII Donut Animation (Terminal)
# Classic math-powered 3D torus animation! Press Ctrl+C to exit.
import math, time, os

A, B = 0, 0
chars = ".,-~:;=!*#$@"

try:
    while True:
        z = [0] * 1760
        b = [' '] * 1760
        for j in range(0, 628, 7):
            for i in range(0, 628, 2):
                c = math.sin(i / 100)
                d = math.cos(j / 100)
                e = math.sin(A)
                f = math.sin(j / 100)
                g = math.cos(A)
                h = d + 2
                D = 1 / (c * h * e + f * g + 5)
                l = math.cos(i / 100)
                m = math.cos(B)
                n = math.sin(B)
                t = c * h * g - f * e
                x = int(40 + 30 * D * (l * h * m - t * n))
                y = int(12 + 15 * D * (l * h * n + t * m))
                o = int(x + 80 * y)
                N = int(8 * ((f * e - c * d * g) * m - c * d * e - f * g - l * d * n))
                if 22 > y > 0 and 80 > x > 0 and D > z[o]:
                    z[o] = D
                    b[o] = chars[N if N > 0 else 0]
        print("\x1b[H" + "".join(b[k] + ("\n" if k % 80 == 79 else "") for k in range(1760)))
        A += 0.08
        B += 0.04
        time.sleep(0.03)
except KeyboardInterrupt:
    print("\n3D Donut stopped.")
