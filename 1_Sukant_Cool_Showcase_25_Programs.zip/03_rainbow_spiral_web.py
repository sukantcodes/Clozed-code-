# 03. Neon Rainbow Hypnotic Spiral Web (Turtle Graphics)
import turtle, colorsys

t = turtle.Turtle()
s = turtle.Screen()
s.bgcolor("black")
t.speed(0)
t.width(2)

n = 36
h = 0
for i in range(250):
    c = colorsys.hsv_to_rgb(h, 1, 1)
    h += 1 / n
    t.pencolor(c)
    t.forward(i * 1.5)
    t.left(59)

t.hideturtle()
turtle.done()
