# 04. 3D Wireframe Rotating Cube (Turtle Graphics)
import turtle, math, time

screen = turtle.Screen()
screen.bgcolor("black")
screen.title("3D Rotating Cube")
screen.tracer(0)

t = turtle.Turtle()
t.hideturtle()
t.color("cyan")
t.pensize(2)

vertices = [
    [-1, -1, -1], [1, -1, -1], [1, 1, -1], [-1, 1, -1],
    [-1, -1, 1],  [1, -1, 1],  [1, 1, 1],  [-1, 1, 1]
]
edges = [
    (0,1), (1,2), (2,3), (3,0),
    (4,5), (5,6), (6,7), (7,4),
    (0,4), (1,5), (2,6), (3,7)
]

angle = 0
try:
    while True:
        t.clear()
        projected = []
        for x, y, z in vertices:
            # Rotate X and Y
            y1 = y * math.cos(angle) - z * math.sin(angle)
            z1 = y * math.sin(angle) + z * math.cos(angle)
            x2 = x * math.cos(angle) + z1 * math.sin(angle)
            z2 = -x * math.sin(angle) + z1 * math.cos(angle)
            factor = 250 / (z2 + 4)
            projected.append((x2 * factor, y1 * factor))

        for start, end in edges:
            t.penup()
            t.goto(projected[start])
            t.pendown()
            t.goto(projected[end])

        screen.update()
        angle += 0.03
        time.sleep(0.016)
except turtle.Terminator:
    pass
