# 05. Recursive Fractal Cherry Blossom Tree (Turtle Graphics)
import turtle, random

screen = turtle.Screen()
screen.bgcolor("#0d1117")
t = turtle.Turtle()
t.speed(0)
t.left(90)
t.penup()
t.goto(0, -250)
t.pendown()

def draw_branch(length):
    if length < 8:
        t.color(random.choice(["#ff7eb9", "#ff65a3", "#ffc2d1", "#ffffff"]))
        t.dot(random.randint(5, 9))
        t.color("#8d6e63")
        return
    t.pensize(max(1, length / 12))
    t.color("#8d6e63")
    t.forward(length)
    angle = random.randint(18, 28)
    shrink = random.uniform(0.72, 0.80)
    t.left(angle)
    draw_branch(length * shrink)
    t.right(angle * 2)
    draw_branch(length * shrink)
    t.left(angle)
    t.backward(length)

draw_branch(105)
t.hideturtle()
turtle.done()
