# 06. Neon Spirograph Mandala Art (Turtle Graphics)
import turtle, colorsys

screen = turtle.Screen()
screen.bgcolor("black")
t = turtle.Turtle()
t.speed(0)
t.width(2)

hue = 0.0
for i in range(72):
    t.pencolor(colorsys.hsv_to_rgb(hue, 1.0, 1.0))
    hue += 1 / 72
    t.circle(120)
    t.left(5)

t.hideturtle()
turtle.done()
