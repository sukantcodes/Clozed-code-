# 07. Animated Solar System Simulation (Turtle Graphics)
import turtle, math, time

screen = turtle.Screen()
screen.bgcolor("black")
screen.title("Solar System Simulation")
screen.tracer(0)

sun = turtle.Turtle()
sun.shape("circle")
sun.color("gold")
sun.shapesize(2.2)

planets_data = [
    ("gray", 0.5, 60, 0.05),
    ("orange", 0.8, 95, 0.035),
    ("deepskyblue", 0.9, 135, 0.025),
    ("red", 0.7, 175, 0.02),
    ("peru", 1.5, 230, 0.012),
    ("khaki", 1.3, 285, 0.009)
]

planets = []
for color, size, radius, speed in planets_data:
    p = turtle.Turtle()
    p.shape("circle")
    p.color(color)
    p.shapesize(size)
    p.penup()
    planets.append([p, radius, speed, 0])

try:
    while True:
        for item in planets:
            p, r, spd, ang = item
            p.goto(r * math.cos(ang), r * math.sin(ang))
            item[3] += spd
        screen.update()
        time.sleep(0.02)
except turtle.Terminator:
    pass
