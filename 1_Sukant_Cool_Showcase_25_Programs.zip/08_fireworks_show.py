# 08. Interactive Fireworks Show (Click anywhere or watch!)
import turtle, random, colorsys

screen = turtle.Screen()
screen.bgcolor("black")
screen.title("Fireworks Display - Click Anywhere!")
t = turtle.Turtle()
t.speed(0)
t.hideturtle()

def launch_firework(x, y):
    color = colorsys.hsv_to_rgb(random.random(), 1, 1)
    t.pencolor(color)
    size = random.randint(40, 110)
    rays = random.randint(18, 30)
    for _ in range(rays):
        t.penup()
        t.goto(x, y)
        t.pendown()
        t.setheading(random.randint(0, 360))
        t.forward(size)

screen.onclick(launch_firework)

for _ in range(15):
    launch_firework(random.randint(-250, 250), random.randint(-150, 220))

turtle.done()
