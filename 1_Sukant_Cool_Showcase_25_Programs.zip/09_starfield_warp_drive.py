# 09. Starfield Warp Speed Animation (Turtle Graphics)
import turtle, random, time

screen = turtle.Screen()
screen.bgcolor("black")
screen.title("Starfield Warp Drive")
screen.tracer(0)

t = turtle.Turtle()
t.hideturtle()
t.color("white")

stars = [[random.uniform(-300, 300), random.uniform(-300, 300), random.uniform(1, 300)] for _ in range(120)]

try:
    while True:
        t.clear()
        for s in stars:
            s[2] -= 5
            if s[2] <= 1:
                s[0] = random.uniform(-300, 300)
                s[1] = random.uniform(-300, 300)
                s[2] = 300
            sx = (s[0] / s[2]) * 250
            sy = (s[1] / s[2]) * 250
            px = (s[0] / (s[2] + 10)) * 250
            py = (s[1] / (s[2] + 10)) * 250
            t.pensize(max(1, (300 - s[2]) / 90))
            t.penup()
            t.goto(px, py)
            t.pendown()
            t.goto(sx, sy)
        screen.update()
        time.sleep(0.02)
except turtle.Terminator:
    pass
