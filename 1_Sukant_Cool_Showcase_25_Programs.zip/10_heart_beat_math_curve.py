# 10. Parametric Math Heart Pulse Animation (Turtle Graphics)
import turtle, math, time

screen = turtle.Screen()
screen.bgcolor("black")
screen.title("Parametric Math Heart")
screen.tracer(0)

t = turtle.Turtle()
t.hideturtle()
t.color("#ff1744")
t.pensize(3)

phase = 0
try:
    while True:
        t.clear()
        scale = 12 + 2 * math.sin(phase)
        t.penup()
        for i in range(200):
            ang = (i / 200) * 2 * math.pi
            x = scale * 16 * (math.sin(ang) ** 3)
            y = scale * (13 * math.cos(ang) - 5 * math.cos(2 * ang) - 2 * math.cos(3 * ang) - math.cos(4 * ang))
            if i == 0:
                t.goto(x, y)
                t.pendown()
            else:
                t.goto(x, y)
        screen.update()
        phase += 0.15
        time.sleep(0.02)
except turtle.Terminator:
    pass
