# 11. Sierpinski Fractal Triangle via Chaos Game (Turtle Graphics)
import turtle, random

screen = turtle.Screen()
screen.bgcolor("black")
screen.tracer(0)

t = turtle.Turtle()
t.hideturtle()
t.penup()

vertices = [(0, 240), (-260, -200), (260, -200)]
colors = ["#00e5ff", "#ff4081", "#76ff03"]
x, y = 0, 0

for i in range(15000):
    idx = random.randint(0, 2)
    vx, vy = vertices[idx]
    x = (x + vx) / 2
    y = (y + vy) / 2
    t.goto(x, y)
    t.dot(2, colors[idx])
    if i % 500 == 0:
        screen.update()

screen.update()
turtle.done()
