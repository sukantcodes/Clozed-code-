# 12. Rotating 3D DNA Double Helix (Terminal Animation)
import math, time

t = 0
try:
    while True:
        for row in range(22):
            angle = t + row * 0.35
            x1 = int(25 + 14 * math.sin(angle))
            x2 = int(25 + 14 * math.sin(angle + math.pi))
            line = [" "] * 50
            low, high = min(x1, x2), max(x1, x2)
            for k in range(low + 1, high):
                line[k] = "-"
            line[x1] = "O"
            line[x2] = "@"
            print("".join(line))
        print("\033[22A", end="")
        t += 0.15
        time.sleep(0.05)
except KeyboardInterrupt:
    print("\n" * 22 + "DNA Animation stopped.")
