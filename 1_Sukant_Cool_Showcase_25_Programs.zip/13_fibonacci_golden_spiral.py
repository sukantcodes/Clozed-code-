# 13. Golden Ratio Fibonacci Spiral Structure (Turtle Graphics)
import turtle, colorsys

screen = turtle.Screen()
screen.bgcolor("black")
t = turtle.Turtle()
t.speed(0)
t.width(2)

a, b = 1, 1
for i in range(14):
    t.pencolor(colorsys.hsv_to_rgb(i / 14, 1, 1))
    for _ in range(4):
        t.forward(b * 3)
        t.left(90)
    t.circle(b * 3, 90)
    a, b = b, a + b

t.hideturtle()
turtle.done()
