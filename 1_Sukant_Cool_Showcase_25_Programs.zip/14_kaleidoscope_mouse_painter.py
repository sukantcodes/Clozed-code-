# 14. Interactive 8-Way Symmetry Kaleidoscope Painter (Drag Mouse!)
import turtle, colorsys

screen = turtle.Screen()
screen.bgcolor("black")
screen.title("Drag Mouse to Paint Kaleidoscope!")

turtles = []
for _ in range(8):
    t = turtle.Turtle()
    t.speed(0)
    t.width(2)
    t.hideturtle()
    turtles.append(t)

hue = [0.0]

def paint(x, y):
    hue[0] = (hue[0] + 0.01) % 1.0
    col = colorsys.hsv_to_rgb(hue[0], 1, 1)
    coords = [
        (x, y), (-x, y), (x, -y), (-x, -y),
        (y, x), (-y, x), (y, -x), (-y, -x)
    ]
    for t, (px, py) in zip(turtles, coords):
        t.pencolor(col)
        t.goto(px, py)

def move_to(x, y):
    coords = [
        (x, y), (-x, y), (x, -y), (-x, -y),
        (y, x), (-y, x), (y, -x), (-y, -x)
    ]
    for t, (px, py) in zip(turtles, coords):
        t.penup()
        t.goto(px, py)
        t.pendown()

screen.onclick(move_to)
turtles[0].ondrag(paint)
screen.onscreenclick(move_to)
turtle.listen()
turtle.done()
