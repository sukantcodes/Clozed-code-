# 15. Classic Neon Snake Game (Arrow Keys to Play!)
import turtle, time, random

delay = 0.1
score = 0

wn = turtle.Screen()
wn.title("Neon Snake Game - Use Arrow Keys")
wn.bgcolor("#111111")
wn.setup(width=600, height=600)
wn.tracer(0)

head = turtle.Turtle()
head.shape("square")
head.color("#00ff88")
head.penup()
head.goto(0, 0)
head.direction = "stop"

food = turtle.Turtle()
food.shape("circle")
food.color("#ff0055")
food.penup()
food.goto(0, 100)

segments = []
pen = turtle.Turtle()
pen.hideturtle()
pen.color("white")
pen.penup()
pen.goto(0, 260)
pen.write("Score: 0", align="center", font=("Courier", 20, "bold"))

def go_up():
    if head.direction != "down": head.direction = "up"
def go_down():
    if head.direction != "up": head.direction = "down"
def go_left():
    if head.direction != "right": head.direction = "left"
def go_right():
    if head.direction != "left": head.direction = "right"

def move():
    if head.direction == "up": head.sety(head.ycor() + 20)
    if head.direction == "down": head.sety(head.ycor() - 20)
    if head.direction == "left": head.setx(head.xcor() - 20)
    if head.direction == "right": head.setx(head.xcor() + 20)

wn.listen()
wn.onkeypress(go_up, "Up")
wn.onkeypress(go_down, "Down")
wn.onkeypress(go_left, "Left")
wn.onkeypress(go_right, "Right")

try:
    while True:
        wn.update()
        if abs(head.xcor()) > 280 or abs(head.ycor()) > 280:
            time.sleep(0.5)
            head.goto(0, 0)
            head.direction = "stop"
            for seg in segments: seg.goto(1000, 1000)
            segments.clear()
            score = 0
            pen.clear()
            pen.write(f"Score: {score}", align="center", font=("Courier", 20, "bold"))

        if head.distance(food) < 20:
            food.goto(random.randrange(-260, 260, 20), random.randrange(-260, 260, 20))
            seg = turtle.Turtle()
            seg.shape("square")
            seg.color("#00cc66")
            seg.penup()
            segments.append(seg)
            score += 10
            pen.clear()
            pen.write(f"Score: {score}", align="center", font=("Courier", 20, "bold"))

        for i in range(len(segments) - 1, 0, -1):
            segments[i].goto(segments[i - 1].xcor(), segments[i - 1].ycor())
        if segments:
            segments[0].goto(head.xcor(), head.ycor())

        move()
        for seg in segments:
            if seg.distance(head) < 20:
                time.sleep(0.5)
                head.goto(0, 0)
                head.direction = "stop"
                for s in segments: s.goto(1000, 1000)
                segments.clear()
                score = 0
                pen.clear()
                pen.write(f"Score: {score}", align="center", font=("Courier", 20, "bold"))
        time.sleep(delay)
except turtle.Terminator:
    pass
