# 16. Two-Player Pong Arcade Game (W/S and Up/Down Arrows)
import turtle, time

wn = turtle.Screen()
wn.title("Pong Arcade - W/S vs Up/Down")
wn.bgcolor("black")
wn.setup(width=800, height=600)
wn.tracer(0)

paddle_a = turtle.Turtle()
paddle_a.shape("square")
paddle_a.color("cyan")
paddle_a.shapesize(stretch_wid=5, stretch_len=1)
paddle_a.penup()
paddle_a.goto(-350, 0)

paddle_b = turtle.Turtle()
paddle_b.shape("square")
paddle_b.color("magenta")
paddle_b.shapesize(stretch_wid=5, stretch_len=1)
paddle_b.penup()
paddle_b.goto(350, 0)

ball = turtle.Turtle()
ball.shape("circle")
ball.color("white")
ball.penup()
ball.dx, ball.dy = 4, 4

score_a, score_b = 0, 0
pen = turtle.Turtle()
pen.hideturtle()
pen.color("white")
pen.penup()
pen.goto(0, 260)
pen.write("Player A: 0  |  Player B: 0", align="center", font=("Courier", 20, "bold"))

wn.listen()
wn.onkeypress(lambda: paddle_a.sety(min(240, paddle_a.ycor() + 30)), "w")
wn.onkeypress(lambda: paddle_a.sety(max(-240, paddle_a.ycor() - 30)), "s")
wn.onkeypress(lambda: paddle_b.sety(min(240, paddle_b.ycor() + 30)), "Up")
wn.onkeypress(lambda: paddle_b.sety(max(-240, paddle_b.ycor() - 30)), "Down")

try:
    while True:
        wn.update()
        ball.setx(ball.xcor() + ball.dx)
        ball.sety(ball.ycor() + ball.dy)

        if abs(ball.ycor()) > 285:
            ball.dy *= -1

        if ball.xcor() > 390:
            ball.goto(0, 0)
            ball.dx *= -1
            score_a += 1
            pen.clear()
            pen.write(f"Player A: {score_a}  |  Player B: {score_b}", align="center", font=("Courier", 20, "bold"))

        if ball.xcor() < -390:
            ball.goto(0, 0)
            ball.dx *= -1
            score_b += 1
            pen.clear()
            pen.write(f"Player A: {score_a}  |  Player B: {score_b}", align="center", font=("Courier", 20, "bold"))

        if (330 < ball.xcor() < 350) and (abs(ball.ycor() - paddle_b.ycor()) < 55):
            ball.setx(330)
            ball.dx *= -1
        if (-350 < ball.xcor() < -330) and (abs(ball.ycor() - paddle_a.ycor()) < 55):
            ball.setx(-330)
            ball.dx *= -1
        time.sleep(0.015)
except turtle.Terminator:
    pass
