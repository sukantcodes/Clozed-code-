# 17. Space Invaders Arcade Shooter (Left/Right Arrows + Space to Fire)
import turtle, random, time

wn = turtle.Screen()
wn.bgcolor("black")
wn.title("Space Invaders - Arrows to Move, Space to Shoot")
wn.setup(600, 600)
wn.tracer(0)

player = turtle.Turtle()
player.shape("triangle")
player.color("lime")
player.penup()
player.setheading(90)
player.goto(0, -250)

bullet = turtle.Turtle()
bullet.shape("square")
bullet.color("yellow")
bullet.shapesize(0.2, 0.8)
bullet.setheading(90)
bullet.penup()
bullet.hideturtle()
bullet_state = "ready"

enemies = []
for i in range(6):
    e = turtle.Turtle()
    e.shape("circle")
    e.color("red")
    e.penup()
    e.goto(-200 + i * 80, 220)
    enemies.append(e)

enemy_dx = 3
score = 0
pen = turtle.Turtle()
pen.hideturtle()
pen.color("white")
pen.penup()
pen.goto(-270, 265)
pen.write("Score: 0", font=("Courier", 16, "bold"))

def move_left():
    player.setx(max(-270, player.xcor() - 25))
def move_right():
    player.setx(min(270, player.xcor() + 25))
def fire():
    global bullet_state
    if bullet_state == "ready":
        bullet_state = "fire"
        bullet.goto(player.xcor(), player.ycor() + 15)
        bullet.showturtle()

wn.listen()
wn.onkeypress(move_left, "Left")
wn.onkeypress(move_right, "Right")
wn.onkeypress(fire, "space")

try:
    while True:
        wn.update()
        for e in enemies:
            e.setx(e.xcor() + enemy_dx)
            if abs(e.xcor()) > 270:
                enemy_dx *= -1
                for item in enemies:
                    item.sety(item.ycor() - 25)
            if bullet_state == "fire" and bullet.distance(e) < 22:
                bullet.hideturtle()
                bullet_state = "ready"
                e.goto(random.randint(-220, 220), 230)
                score += 10
                pen.clear()
                pen.write(f"Score: {score}", font=("Courier", 16, "bold"))

        if bullet_state == "fire":
            bullet.sety(bullet.ycor() + 15)
            if bullet.ycor() > 280:
                bullet.hideturtle()
                bullet_state = "ready"
        time.sleep(0.02)
except turtle.Terminator:
    pass
