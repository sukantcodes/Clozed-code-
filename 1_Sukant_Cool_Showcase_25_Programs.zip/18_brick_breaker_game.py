# 18. Brick Breaker Arcade Game (Left/Right Arrows to Play)
import turtle, time

wn = turtle.Screen()
wn.bgcolor("#0b0c10")
wn.title("Brick Breaker - Use Left/Right Arrows")
wn.setup(600, 600)
wn.tracer(0)

paddle = turtle.Turtle()
paddle.shape("square")
paddle.color("#66fcf1")
paddle.shapesize(0.8, 5)
paddle.penup()
paddle.goto(0, -250)

ball = turtle.Turtle()
ball.shape("circle")
ball.color("white")
ball.penup()
ball.goto(0, -200)
ball.dx, ball.dy = 3.5, 3.5

bricks = []
colors = ["#ff4d4d", "#ffa64d", "#ffff4d", "#4dff88"]
for row in range(4):
    for col in range(7):
        b = turtle.Turtle()
        b.shape("square")
        b.color(colors[row])
        b.shapesize(1, 3.5)
        b.penup()
        b.goto(-240 + col * 80, 220 - row * 30)
        bricks.append(b)

wn.listen()
wn.onkeypress(lambda: paddle.setx(max(-240, paddle.xcor() - 35)), "Left")
wn.onkeypress(lambda: paddle.setx(min(240, paddle.xcor() + 35)), "Right")

try:
    while True:
        wn.update()
        ball.setx(ball.xcor() + ball.dx)
        ball.sety(ball.ycor() + ball.dy)

        if abs(ball.xcor()) > 285: ball.dx *= -1
        if ball.ycor() > 285: ball.dy *= -1
        if ball.ycor() < -290:
            ball.goto(0, -200)
            ball.dy = 3.5

        if (-260 < ball.ycor() < -235) and (abs(ball.xcor() - paddle.xcor()) < 55):
            ball.dy = abs(ball.dy)

        for b in bricks[:]:
            if abs(ball.xcor() - b.xcor()) < 42 and abs(ball.ycor() - b.ycor()) < 18:
                b.hideturtle()
                bricks.remove(b)
                ball.dy *= -1
                break
        time.sleep(0.015)
except turtle.Terminator:
    pass
