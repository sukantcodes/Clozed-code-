# 19. Flappy Square Arcade Game (Press Space to Jump!)
import turtle, random, time

wn = turtle.Screen()
wn.bgcolor("#1a1a2e")
wn.title("Flappy Neon - Press SPACE to Flap")
wn.setup(500, 600)
wn.tracer(0)

bird = turtle.Turtle()
bird.shape("square")
bird.color("#f9d423")
bird.penup()
bird.goto(-120, 0)
bird.dy = 0

top_pipe = turtle.Turtle()
top_pipe.shape("square")
top_pipe.color("#00f260")
top_pipe.shapesize(15, 3)
top_pipe.penup()
top_pipe.goto(250, 220)

bot_pipe = turtle.Turtle()
bot_pipe.shape("square")
bot_pipe.color("#00f260")
bot_pipe.shapesize(15, 3)
bot_pipe.penup()
bot_pipe.goto(250, -220)

def flap():
    bird.dy = 7.5

wn.listen()
wn.onkeypress(flap, "space")

try:
    while True:
        wn.update()
        bird.dy -= 0.45
        bird.sety(bird.ycor() + bird.dy)

        top_pipe.setx(top_pipe.xcor() - 4)
        bot_pipe.setx(bot_pipe.xcor() - 4)

        if top_pipe.xcor() < -270:
            gap_y = random.randint(-90, 90)
            top_pipe.goto(270, gap_y + 220)
            bot_pipe.goto(270, gap_y - 220)

        if abs(bird.ycor()) > 285 or (abs(bird.xcor() - top_pipe.xcor()) < 35 and (bird.ycor() > top_pipe.ycor() - 150 or bird.ycor() < bot_pipe.ycor() + 150)):
            bird.goto(-120, 0)
            bird.dy = 0
            top_pipe.goto(270, 220)
            bot_pipe.goto(270, -220)
        time.sleep(0.02)
except turtle.Terminator:
    pass
