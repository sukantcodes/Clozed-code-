# 20. Colorful Turtle Grand Prix Race (Watch or Guess the Winner!)
import turtle, random

wn = turtle.Screen()
wn.bgcolor("#1e272e")
wn.title("Turtle Grand Prix Race!")

line = turtle.Turtle()
line.hideturtle()
line.color("white")
line.penup()
line.goto(230, 160)
line.pendown()
line.goto(230, -160)

colors = ["red", "cyan", "yellow", "lime", "magenta"]
racers = []
for idx, col in enumerate(colors):
    r = turtle.Turtle()
    r.shape("turtle")
    r.color(col)
    r.shapesize(1.5)
    r.penup()
    r.goto(-240, 100 - idx * 50)
    racers.append(r)

winner = None
while not winner:
    for r in racers:
        r.forward(random.randint(2, 10))
        if r.xcor() >= 230:
            winner = r.pencolor().upper()
            break

msg = turtle.Turtle()
msg.hideturtle()
msg.color("gold")
msg.write(f"WINNER: {winner} TURTLE!", align="center", font=("Arial", 22, "bold"))
turtle.done()
