# 21. Oscilloscope Lissajous Wave Harmonics (Turtle Graphics)
import turtle, math, colorsys

screen = turtle.Screen()
screen.bgcolor("black")
screen.title("Lissajous Harmonic Waves")
screen.tracer(0)

t = turtle.Turtle()
t.hideturtle()
t.pensize(2)

for step in range(400):
    t.pencolor(colorsys.hsv_to_rgb(step / 400, 1, 1))
    ang = (step / 400) * 2 * math.pi
    x = 240 * math.sin(3 * ang + math.pi / 2)
    y = 240 * math.sin(4 * ang)
    if step == 0:
        t.penup()
        t.goto(x, y)
        t.pendown()
    else:
        t.goto(x, y)
    if step % 5 == 0:
        screen.update()

screen.update()
turtle.done()
