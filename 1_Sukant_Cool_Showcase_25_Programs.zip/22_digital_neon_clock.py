# 22. Live Digital Neon Clock (Turtle Graphics)
import turtle, time

screen = turtle.Screen()
screen.bgcolor("black")
screen.title("Live Digital Neon Clock")
screen.tracer(0)

pen = turtle.Turtle()
pen.hideturtle()
pen.color("#00ffcc")

try:
    while True:
        pen.clear()
        current_time = time.strftime("%I:%M:%S %p")
        current_date = time.strftime("%A, %d %B %Y")
        pen.penup()
        pen.goto(0, 10)
        pen.write(current_time, align="center", font=("Courier", 42, "bold"))
        pen.goto(0, -35)
        pen.write(current_date, align="center", font=("Courier", 16, "normal"))
        screen.update()
        time.sleep(0.5)
except turtle.Terminator:
    pass
