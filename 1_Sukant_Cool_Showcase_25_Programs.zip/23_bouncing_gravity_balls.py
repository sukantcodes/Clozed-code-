# 23. Multi-Ball Physics & Gravity Simulation (Turtle Graphics)
import turtle, random, time

screen = turtle.Screen()
screen.bgcolor("black")
screen.title("Physics Gravity Simulation")
screen.tracer(0)

balls = []
colors = ["#ff5252", "#448aff", "#69f0ae", "#ffd740", "#e040fb", "#18ffff"]
for col in colors:
    b = turtle.Turtle()
    b.shape("circle")
    b.color(col)
    b.shapesize(1.3)
    b.penup()
    b.goto(random.randint(-200, 200), random.randint(50, 240))
    b.dx = random.choice([-4, -3, 3, 4])
    b.dy = 0
    balls.append(b)

try:
    while True:
        for b in balls:
            b.dy -= 0.35
            b.setx(b.xcor() + b.dx)
            b.sety(b.ycor() + b.dy)
            if abs(b.xcor()) > 280:
                b.dx *= -1
            if b.ycor() < -250:
                b.sety(-250)
                b.dy *= -0.92
        screen.update()
        time.sleep(0.016)
except turtle.Terminator:
    pass
