# 24. Randomized DFS Maze Generator Animation (Turtle Graphics)
import turtle, random

screen = turtle.Screen()
screen.bgcolor("#121212")
screen.title("Live Maze Generator")
screen.tracer(0)

t = turtle.Turtle()
t.hideturtle()
t.color("#00e676")
t.pensize(3)

COLS, ROWS = 15, 15
SIZE = 28
OFFSET_X = -COLS * SIZE // 2
OFFSET_Y = -ROWS * SIZE // 2

visited = [[False] * COLS for _ in range(ROWS)]

def draw_cell(r, c):
    x = OFFSET_X + c * SIZE + SIZE // 2
    y = OFFSET_Y + r * SIZE + SIZE // 2
    t.penup()
    t.goto(x, y)
    t.dot(SIZE - 8, "#00e676")

def carve(r, c):
    visited[r][c] = True
    draw_cell(r, c)
    dirs = [(0, 1), (1, 0), (0, -1), (-1, 0)]
    random.shuffle(dirs)
    for dr, dc in dirs:
        nr, nc = r + dr, c + dc
        if 0 <= nr < ROWS and 0 <= nc < COLS and not visited[nr][nc]:
            x1 = OFFSET_X + c * SIZE + SIZE // 2
            y1 = OFFSET_Y + r * SIZE + SIZE // 2
            x2 = OFFSET_X + nc * SIZE + SIZE // 2
            y2 = OFFSET_Y + nr * SIZE + SIZE // 2
            t.penup()
            t.goto(x1, y1)
            t.pendown()
            t.pensize(SIZE - 8)
            t.goto(x2, y2)
            screen.update()
            carve(nr, nc)

carve(0, 0)
screen.update()
turtle.done()
