# 25. Rotating Geometric Polygon Tunnel Illusion (Turtle Graphics)
import turtle, colorsys

screen = turtle.Screen()
screen.bgcolor("black")
t = turtle.Turtle()
t.speed(0)
t.width(2)

sides = 6
for i in range(90):
    t.pencolor(colorsys.hsv_to_rgb(i / 90, 1, 1))
    for _ in range(sides):
        t.forward(i * 3)
        t.left(360 / sides)
    t.left(10)

t.hideturtle()
turtle.done()
