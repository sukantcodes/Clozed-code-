# 01. Hollywood Hacker Command Center GUI (Touch & Click Interactive!)
# Click the glowing control buttons (BREACH, TRACE, ENCRYPT, OVERRIDE) to trigger live effects!
import tkinter as tk
import random, math, time

root = tk.Tk()
root.title("CYBER-OPS // COMMAND CENTER v9.4")
root.geometry("960x600")
root.configure(bg="#05080b")

mode = ["MONITORING"]
alert_color = ["#00ff66"]

top = tk.Frame(root, bg="#0a1118", height=45)
top.pack(fill="x", padx=8, pady=6)
status_lbl = tk.Label(top, text="● SYSTEM ONLINE // STATUS: MONITORING // NODE: BLR-774",
                      fg="#00ff66", bg="#0a1118", font=("Consolas", 12, "bold"))
status_lbl.pack(side="left", padx=12, pady=8)
clock_lbl = tk.Label(top, text="", fg="#00e5ff", bg="#0a1118", font=("Consolas", 12, "bold"))
clock_lbl.pack(side="right", padx=12)

mid = tk.Frame(root, bg="#05080b")
mid.pack(fill="both", expand=True, padx=8)

left_log = tk.Text(mid, bg="#030609", fg="#00ff66", font=("Consolas", 9), width=48, bd=1, relief="solid")
left_log.pack(side="left", fill="both", expand=True, padx=(0, 6))

right_frame = tk.Frame(mid, bg="#05080b")
right_frame.pack(side="right", fill="both", expand=True)

radar_cv = tk.Canvas(right_frame, bg="#030609", height=260, highlightthickness=1, highlightbackground="#00ff66")
radar_cv.pack(fill="both", expand=True, pady=(0, 6))

wave_cv = tk.Canvas(right_frame, bg="#030609", height=160, highlightthickness=1, highlightbackground="#00e5ff")
wave_cv.pack(fill="both", expand=True)

btn_frame = tk.Frame(root, bg="#05080b")
btn_frame.pack(fill="x", padx=8, pady=8)

def set_mode(new_mode, col, msg):
    mode[0] = new_mode
    alert_color[0] = col
    status_lbl.config(text=f"● SYSTEM ACTIVE // STATUS: {new_mode} // {msg}", fg=col)
    left_log.insert("end", f"\n>>> [{new_mode}] {msg} <<<\n")
    left_log.see("end")

buttons = [
    ("INITIATE BREACH", "#ff1744", "FIREWALL BYPASS IN PROGRESS..."),
    ("SATELLITE TRACE", "#00e5ff", "LOCKING ORBITAL SIGNAL..."),
    ("QUANTUM ENCRYPT", "#d500f9", "ROTATING 4096-BIT KEYS..."),
    ("GHOST PROTOCOL", "#00ff66", "MASKING IP & MAC ADDRESS...")
]
for txt, col, msg in buttons:
    tk.Button(btn_frame, text=txt, bg="#0d1620", fg=col, activebackground=col, activeforeground="#000",
              font=("Consolas", 10, "bold"), bd=1, relief="solid", padx=14, pady=6,
              command=lambda t=txt, c=col, m=msg: set_mode(t, c, m)).pack(side="left", expand=True, fill="x", padx=4)

angle = [0.0]
blips = [(random.randint(-90, 90), random.randint(-90, 90)) for _ in range(7)]
wave_vals = [random.randint(20, 120) for _ in range(45)]

def update():
    clock_lbl.config(text=time.strftime("UTC %H:%M:%S"))
    # Live hex & log stream
    hx = " ".join(f"{random.randint(0,255):02X}" for _ in range(8))
    ip = f"{random.randint(10,220)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"
    left_log.insert("end", f"[{mode[0][:6]}] {ip:<15} | {hx}\n")
    if int(left_log.index("end-1c").split(".")[0]) > 40:
        left_log.delete("1.0", "5.0")
    left_log.see("end")

    # Radar
    radar_cv.delete("all")
    w = max(radar_cv.winfo_width(), 200)
    h = max(radar_cv.winfo_height(), 200)
    cx, cy = w // 2, h // 2
    rad = min(cx, cy) - 18
    col = alert_color[0]
    for r in (rad, rad * 0.66, rad * 0.33):
        radar_cv.create_oval(cx - r, cy - r, cx + r, cy + r, outline="#123524", width=1)
    radar_cv.create_line(cx - rad, cy, cx + rad, cy, fill="#123524")
    radar_cv.create_line(cx, cy - rad, cx, cy + rad, fill="#123524")
    ex = cx + rad * math.cos(angle[0])
    ey = cy + rad * math.sin(angle[0])
    radar_cv.create_line(cx, cy, ex, ey, fill=col, width=2)
    for bx, by in blips:
        radar_cv.create_oval(cx + bx - 3, cy + by - 3, cx + bx + 3, cy + by + 3, fill=col, outline="")
    angle[0] += 0.14

    # Network Telemetry Wave
    wave_cv.delete("all")
    ww = max(wave_cv.winfo_width(), 200)
    wh = max(wave_cv.winfo_height(), 100)
    wave_vals.pop(0)
    wave_vals.append(random.randint(15, wh - 20))
    step = ww / (len(wave_vals) - 1)
    pts = []
    for i, v in enumerate(wave_vals):
        pts.extend([i * step, wh - v])
    wave_cv.create_line(pts, fill="#00e5ff", width=2, smooth=True)
    wave_cv.create_text(10, 12, text="NET TRAFFIC // PACKETS/SEC", anchor="w", fill="#00e5ff", font=("Consolas", 9, "bold"))

    root.after(70, update)

update()
root.mainloop()
