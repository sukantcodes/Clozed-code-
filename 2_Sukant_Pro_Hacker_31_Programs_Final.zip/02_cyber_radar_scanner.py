# 02. Interactive Military & Hacker Radar Scanner (Touch/Click to Lock Targets!)
import tkinter as tk
import math, random

root = tk.Tk()
root.title("TACTICAL RADAR // CLICK OR TOUCH TO LOCK TARGETS")
root.configure(bg="#020b05")

SIZE = 580
cv = tk.Canvas(root, width=SIZE, height=SIZE, bg="#020b05", highlightthickness=0)
cv.pack()

cx = cy = SIZE // 2
R = 250
angle = [0.0]
targets = []

def add_target(event):
    dx, dy = event.x - cx, event.y - cy
    if math.hypot(dx, dy) <= R:
        targets.append({
            "x": event.x, "y": event.y,
            "id": f"TGT-{random.randint(100,999)}",
            "alpha": 1.0, "locked": True
        })

cv.bind("<Button-1>", add_target)
cv.bind("<B1-Motion>", lambda e: add_target(e) if random.random() < 0.15 else None)

for _ in range(5):
    a = random.uniform(0, 2 * math.pi)
    d = random.uniform(40, R - 20)
    targets.append({"x": cx + d * math.cos(a), "y": cy + d * math.sin(a),
                    "id": f"UNK-{random.randint(10,99)}", "alpha": 0.4, "locked": False})

def loop():
    cv.delete("all")
    for frac in (1.0, 0.75, 0.5, 0.25):
        r = R * frac
        cv.create_oval(cx - r, cy - r, cx + r, cy + r, outline="#0a4f24", width=1)
    for deg in range(0, 360, 30):
        rad = math.radians(deg)
        cv.create_line(cx, cy, cx + R * math.cos(rad), cy + R * math.sin(rad), fill="#073317")

    # Sweep trail
    for i in range(12):
        a = angle[0] - i * 0.04
        g = max(20, 255 - i * 20)
        col = f"#00{g:02x}33"
        cv.create_line(cx, cy, cx + R * math.cos(a), cy + R * math.sin(a), fill=col, width=2)

    sweep_deg = math.degrees(angle[0]) % 360
    for t in targets:
        tx, ty = t["x"], t["y"]
        t_deg = math.degrees(math.atan2(ty - cy, tx - cx)) % 360
        if abs((t_deg - sweep_deg + 180) % 360 - 180) < 8:
            t["alpha"] = 1.0
        else:
            t["alpha"] = max(0.18, t["alpha"] - 0.015)

        if t["locked"]:
            col = "#ff1744"
            cv.create_rectangle(tx - 8, ty - 8, tx + 8, ty + 8, outline=col, width=2)
            cv.create_text(tx + 12, ty - 10, text=f"{t['id']} [{int(tx-cx)},{int(cy-ty)}]",
                           fill=col, anchor="w", font=("Consolas", 8, "bold"))
        else:
            g = int(255 * t["alpha"])
            col = f"#00{g:02x}44"
            cv.create_oval(tx - 4, ty - 4, tx + 4, ty + 4, fill=col, outline="")
            if t["alpha"] > 0.6:
                cv.create_text(tx + 8, ty, text=t["id"], fill=col, anchor="w", font=("Consolas", 8))

    cv.create_text(15, 18, text=f"SWEEP: {sweep_deg:05.1f}°  |  TARGETS: {len(targets)}  |  CLICK/TOUCH TO LOCK",
                   fill="#00ff66", anchor="w", font=("Consolas", 10, "bold"))
    angle[0] += 0.06
    root.after(25, loop)

loop()
root.mainloop()
