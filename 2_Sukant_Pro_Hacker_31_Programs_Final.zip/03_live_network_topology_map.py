# 03. Interactive Global Cyber Network Map (Touch/Click any Node to Fire Data Surge!)
import tkinter as tk
import random, math

root = tk.Tk()
root.title("CYBER TOPOLOGY // CLICK ANY SERVER NODE TO LAUNCH PACKET SURGE")
W, H = 860, 540
cv = tk.Canvas(root, width=W, height=H, bg="#04070d", highlightthickness=0)
cv.pack()

cities = ["BLR-CORE", "MUM-HUB", "SGP-01", "TOK-9", "FRA-EU", "LON-UK", "NYC-US", "SFO-BAY", "SYD-AU", "DXB-ME"]
nodes = []
for i, name in enumerate(cities):
    ang = (i / len(cities)) * 2 * math.pi
    rx = 310 + random.randint(-45, 45)
    ry = 185 + random.randint(-35, 35)
    nodes.append({"name": name, "x": W // 2 + rx * math.cos(ang), "y": H // 2 + ry * math.sin(ang), "pulse": 0})

edges = []
for i in range(len(nodes)):
    for j in range(i + 1, len(nodes)):
        if random.random() < 0.42:
            edges.append((i, j))

packets = []

def spawn_surge(idx, col="#ff1744"):
    nodes[idx]["pulse"] = 18
    for a, b in edges:
        if a == idx or b == idx:
            dst = b if a == idx else a
            packets.append({"src": idx, "dst": dst, "t": 0.0, "spd": random.uniform(0.025, 0.055), "col": col})

def on_click(e):
    best_i = min(range(len(nodes)), key=lambda i: math.hypot(nodes[i]["x"] - e.x, nodes[i]["y"] - e.y))
    spawn_surge(best_i, random.choice(["#ff1744", "#00e5ff", "#ffd600", "#00ff66"]))

cv.bind("<Button-1>", on_click)

def animate():
    cv.delete("all")
    if random.random() < 0.12:
        a, b = random.choice(edges)
        packets.append({"src": a, "dst": b, "t": 0.0, "spd": 0.03, "col": "#00e5ff"})

    for a, b in edges:
        cv.create_line(nodes[a]["x"], nodes[a]["y"], nodes[b]["x"], nodes[b]["y"], fill="#10253a", width=1)

    for p in packets[:]:
        p["t"] += p["spd"]
        if p["t"] >= 1.0:
            nodes[p["dst"]]["pulse"] = max(nodes[p["dst"]]["pulse"], 10)
            packets.remove(p)
            continue
        sx, sy = nodes[p["src"]]["x"], nodes[p["src"]]["y"]
        dx, dy = nodes[p["dst"]]["x"], nodes[p["dst"]]["y"]
        px = sx + (dx - sx) * p["t"]
        py = sy + (dy - sy) * p["t"]
        cv.create_oval(px - 4, py - 4, px + 4, py + 4, fill=p["col"], outline="")

    for n in nodes:
        x, y = n["x"], n["y"]
        if n["pulse"] > 0:
            r = 24 - n["pulse"]
            cv.create_oval(x - r, y - r, x + r, y + r, outline="#00e5ff", width=2)
            n["pulse"] -= 1
        cv.create_oval(x - 8, y - 8, x + 8, y + 8, fill="#00ff66", outline="#ffffff", width=1)
        cv.create_text(x, y - 16, text=n["name"], fill="#80d8ff", font=("Consolas", 9, "bold"))

    cv.create_text(14, 18, text=f"ACTIVE PACKETS: {len(packets)}  |  CLICK/TOUCH ANY NODE TO TRIGGER SURGE",
                   fill="#00ff66", anchor="w", font=("Consolas", 10, "bold"))
    root.after(25, animate)

animate()
root.mainloop()
