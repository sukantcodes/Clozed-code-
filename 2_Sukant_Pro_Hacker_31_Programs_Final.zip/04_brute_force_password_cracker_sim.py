# 04. High-Speed Hacker Brute-Force Cracker Simulation (Terminal)
# Enter any fake target password (or press Enter for default) and watch the cracker lock on!
import random, time, hashlib, sys

chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789!@#$%^&*"
target = input("\033[96m[?] Enter target passphrase to crack (default: CyberKnight#99): \033[0m").strip()
if not target:
    target = "CyberKnight#99"

target_hash = hashlib.sha256(target.encode()).hexdigest()
print(f"\033[93m[*] TARGET SHA-256: {target_hash}\033[0m")
print("\033[92m[*] INITIALIZING MULTI-THREADED DICTIONARY + BRUTE ENGINE...\033[0m\n")
time.sleep(0.7)

cracked = [" "] * len(target)
attempts = 0
start = time.time()

for idx in range(len(target)):
    for _ in range(random.randint(12, 26)):
        attempts += random.randint(1500, 9500)
        cracked[idx] = random.choice(chars)
        display = "".join(cracked)
        fake_h = hashlib.sha256(display.encode()).hexdigest()[:24]
        sys.stdout.write(f"\r\033[91m[CRACKING]\033[0m {display:<22} | HASH: {fake_h}... | KEYS: {attempts:,}")
        sys.stdout.flush()
        time.sleep(0.03)
    cracked[idx] = target[idx]
    display = "".join(cracked)
    sys.stdout.write(f"\r\033[92m[LOCKED  ]\033[0m {display:<22} | MATCHED CHAR #{idx+1:<2}              | KEYS: {attempts:,}")
    sys.stdout.flush()
    time.sleep(0.06)

elapsed = time.time() - start
print(f"\n\n\033[92m[✓] ACCESS GRANTED! PASSWORD RECOVERED: {target}\033[0m")
print(f"\033[96m[i] Total simulated keys tested: {attempts:,} in {elapsed:.2f}s\033[0m")
