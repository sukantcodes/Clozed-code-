# 05. Real-Time System Recon & Diagnostics HUD (Reads Live System Info!)
import tkinter as tk
import platform, socket, os, sys, random, time

root = tk.Tk()
root.title("SYS-RECON HUD // LIVE DIAGNOSTICS")
root.geometry("760x480")
root.configure(bg="#06090f")

hostname = socket.gethostname()
try:
    local_ip = socket.gethostbyname(hostname)
except Exception:
    local_ip = "127.0.0.1"

info_lines = [
    f"HOST MACHINE   : {hostname}",
    f"LOCAL IP ADDR  : {local_ip}",
    f"OS PLATFORM    : {platform.system()} {platform.release()}",
    f"ARCHITECTURE   : {platform.machine()} ({platform.architecture()[0]})",
    f"CPU CORES      : {os.cpu_count()} Logical Processors",
    f"PYTHON RUNTIME : {sys.version.split()[0]}",
    f"CURRENT USER   : {os.environ.get('USER') or os.environ.get('USERNAME') or 'ROOT'}"
]

hdr = tk.Label(root, text="/// SYSTEM RECONNAISSANCE & TELEMETRY HUD ///",
               fg="#00e5ff", bg="#06090f", font=("Consolas", 14, "bold"))
hdr.pack(pady=10)

info_box = tk.Label(root, text="\n".join(info_lines), fg="#00ff66", bg="#0b121e",
                    font=("Consolas", 11), justify="left", anchor="w", padx=18, pady=12, relief="solid", bd=1)
info_box.pack(fill="x", padx=20)

cv = tk.Canvas(root, bg="#0b121e", height=210, highlightthickness=1, highlightbackground="#00e5ff")
cv.pack(fill="both", expand=True, padx=20, pady=14)

metrics = [("CPU LOAD", "#00ff66", 45), ("MEM ALLOC", "#00e5ff", 62),
           ("NET I/O", "#ffd600", 30), ("GPU SHADER", "#ff4081", 55)]

def refresh():
    cv.delete("all")
    w = max(cv.winfo_width(), 400)
    for idx, (label, col, val) in enumerate(metrics):
        new_val = max(8, min(98, val + random.randint(-9, 9)))
        metrics[idx] = (label, col, new_val)
        y = 30 + idx * 45
        cv.create_text(20, y, text=f"{label:<11} {new_val:02d}%", fill=col, anchor="w", font=("Consolas", 11, "bold"))
        bar_x = 175
        bar_w = w - 210
        cv.create_rectangle(bar_x, y - 10, bar_x + bar_w, y + 10, outline="#1c3144", width=1)
        cv.create_rectangle(bar_x, y - 10, bar_x + int(bar_w * new_val / 100), y + 10, fill=col, outline="")
    cv.create_text(w - 20, 195, text=f"SCAN TIMESTAMP: {time.strftime('%Y-%m-%d %H:%M:%S')}",
                   fill="#80d8ff", anchor="e", font=("Consolas", 9))
    root.after(220, refresh)

refresh()
root.mainloop()
