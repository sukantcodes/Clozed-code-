# 06. Live Cyber Memory Hex-Dump & Packet Sniffer Visualizer (Terminal)
# Press Ctrl+C to stop the live hex stream.
import random, time

addr = 0x7FF0A100
print("\033[96m[MEM-SNIFFER v3.1] ATTACHED TO VIRTUAL KERNEL RING 0...\033[0m\n")
time.sleep(0.5)

try:
    while True:
        raw = [random.randint(0, 255) for _ in range(16)]
        hex_part = " ".join(f"{b:02X}" for b in raw)
        ascii_part = "".join(chr(b) if 32 <= b <= 126 else "." for b in raw)
        col = "\033[92m" if random.random() > 0.12 else "\033[91m"
        print(f"\033[96m0x{addr:08X}\033[0m  {col}{hex_part}\033[0m  |\033[93m{ascii_part}\033[0m|")
        addr += 16
        time.sleep(0.045)
except KeyboardInterrupt:
    print("\n\033[91m[!] Memory dump terminated safely.\033[0m")
