# 07. Interactive Cyber Encryption & SHA-256 Vault GUI (Touch/Click Ready)
import tkinter as tk
import hashlib, base64

root = tk.Tk()
root.title("QUANTUM ENCRYPTION VAULT")
root.geometry("680x440")
root.configure(bg="#070a0f")

tk.Label(root, text="QUANTUM CIPHER & HASH VAULT", fg="#00ff66", bg="#070a0f",
         font=("Consolas", 15, "bold")).pack(pady=10)

tk.Label(root, text="ENTER SECRET MESSAGE:", fg="#00e5ff", bg="#070a0f", font=("Consolas", 10, "bold")).pack(anchor="w", padx=20)
inp = tk.Entry(root, bg="#0f1722", fg="#ffffff", insertbackground="#00ff66", font=("Consolas", 12), relief="solid", bd=1)
inp.pack(fill="x", padx=20, pady=6)
inp.insert(0, "Meet at RJS Lab at 14:00")

tk.Label(root, text="SECRET KEY (NUMBER):", fg="#00e5ff", bg="#070a0f", font=("Consolas", 10, "bold")).pack(anchor="w", padx=20)
key_inp = tk.Entry(root, bg="#0f1722", fg="#ffd600", insertbackground="#ffd600", font=("Consolas", 12), width=12, relief="solid", bd=1)
key_inp.pack(anchor="w", padx=20, pady=4)
key_inp.insert(0, "42")

out_box = tk.Text(root, bg="#04070b", fg="#00ff66", font=("Consolas", 10), height=10, relief="solid", bd=1)
out_box.pack(fill="both", expand=True, padx=20, pady=10)

def xor_cipher(text, key):
    return "".join(chr(ord(c) ^ (key % 255)) for c in text)

def encrypt():
    txt = inp.get()
    k = int(key_inp.get()) if key_inp.get().isdigit() else 42
    enc = base64.b64encode(xor_cipher(txt, k).encode("utf-8")).decode("utf-8")
    h = hashlib.sha256(txt.encode("utf-8")).hexdigest()
    out_box.delete("1.0", "end")
    out_box.insert("end", f"[ENCRYPTED BASE64 PAYLOAD]\n{enc}\n\n[SHA-256 FINGERPRINT]\n{h}\n")

def decrypt():
    txt = inp.get().strip()
    k = int(key_inp.get()) if key_inp.get().isdigit() else 42
    out_box.delete("1.0", "end")
    try:
        dec = xor_cipher(base64.b64decode(txt).decode("utf-8"), k)
        out_box.insert("end", f"[DECRYPTED PLAINTEXT]\n{dec}\n")
    except Exception:
        out_box.insert("end", "[ERROR] Paste a valid Base64 payload in the message box to decrypt.\n")

bf = tk.Frame(root, bg="#070a0f")
bf.pack(pady=8)
tk.Button(bf, text="ENCRYPT PAYLOAD", bg="#003d1f", fg="#00ff66", font=("Consolas", 11, "bold"),
          padx=16, pady=6, command=encrypt).pack(side="left", padx=10)
tk.Button(bf, text="DECRYPT PAYLOAD", bg="#002b44", fg="#00e5ff", font=("Consolas", 11, "bold"),
          padx=16, pady=6, command=decrypt).pack(side="left", padx=10)

encrypt()
root.mainloop()
