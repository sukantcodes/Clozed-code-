# 08. Orbital Satellite Telemetry Tracker HUD (Click/Touch to Deploy Ground Station!)
import tkinter as tk
import math, random

root = tk.Tk()
root.title("ORBITAL SATELLITE TRACKER // CLICK TO ADD GROUND STATION")
W, H = 860, 460
cv = tk.Canvas(root, width=W, height=H, bg="#030812", highlightthickness=0)
cv.pack()

sats = [
    {"name": "SAT-ISS-01", "phase": 0.0, "amp": 135, "spd": 0.022, "col": "#00ff66"},
    {"name": "SAT-RECON-7", "phase": 2.1, "amp": 165, "spd": 0.031, "col": "#ff1744"},
    {"name": "SAT-STAR-X", "phase": 4.2, "amp": 100, "spd": 0.017, "col": "#00e5ff"}
]
stations = [(610, 250, "BLR-STATION")]

def add_station(e):
    stations.append((e.x, e.y, f"STN-{len(stations)+1}"))

cv.bind("<Button-1>", add_station)

def update():
    cv.delete("all")
    # Lat/Lon Grid
    for x in range(0, W, 60):
        cv.create_line(x, 0, x, H, fill="#0b1d33")
    for y in range(0, H, 50):
        cv.create_line(0, y, W, y, fill="#0b1d33")
    cv.create_line(0, H // 2, W, H // 2, fill="#163c66", dash=(4, 4))

    for sx, sy, sname in stations:
        cv.create_rectangle(sx - 5, sy - 5, sx + 5, sy + 5, outline="#ffd600", width=2)
        cv.create_text(sx + 8, sy - 8, text=sname, fill="#ffd600", anchor="w", font=("Consolas", 8, "bold"))

    for s in sats:
        # Orbit path
        pts = []
        for x in range(0, W, 12):
            y = H // 2 + s["amp"] * math.sin((x / W) * 2 * math.pi + s["phase"])
            pts.extend([x, y])
        cv.create_line(pts, fill=s["col"], width=1, dash=(3, 5))

        # Satellite position
        pos_x = ((s["phase"] * 120) % W)
        pos_y = H // 2 + s["amp"] * math.sin((pos_x / W) * 2 * math.pi + s["phase"])
        cv.create_oval(pos_x - 7, pos_y - 7, pos_x + 7, pos_y + 7, fill=s["col"], outline="#fff")
        cv.create_oval(pos_x - 35, pos_y - 35, pos_x + 35, pos_y + 35, outline=s["col"], dash=(2, 2))
        lat = (H // 2 - pos_y) / (H // 2) * 90
        lon = (pos_x - W // 2) / (W // 2) * 180
        cv.create_text(pos_x + 12, pos_y - 12, text=f"{s['name']} ({lat:+.1f}°, {lon:+.1f}°)",
                       fill=s["col"], anchor="w", font=("Consolas", 8, "bold"))

        # Link to nearby ground stations
        for sx, sy, _ in stations:
            if math.hypot(pos_x - sx, pos_y - sy) < 160:
                cv.create_line(pos_x, pos_y, sx, sy, fill="#ffd600", width=1)

        s["phase"] += s["spd"]

    cv.create_text(14, 16, text="GLOBAL ORBITAL TELEMETRY  |  CLICK/TOUCH TO DEPLOY GROUND STATION",
                   fill="#00e5ff", anchor="w", font=("Consolas", 10, "bold"))
    root.after(30, update)

update()
root.mainloop()
