# 09. Interactive Cyber Audio Spectrum Visualizer (Touch/Drag Across Bars to Boost!)
import tkinter as tk
import math, random, colorsys

root = tk.Tk()
root.title("CYBER SPECTRUM ANALYZER // TOUCH OR DRAG TO MODULATE FREQUENCIES")
W, H = 820, 440
cv = tk.Canvas(root, width=W, height=H, bg="#05050a", highlightthickness=0)
cv.pack()

BARS = 40
levels = [40.0] * BARS
peaks = [40.0] * BARS
phase = [0.0]
pointer = [-1, -1]

def touch(e):
    pointer[0], pointer[1] = e.x, e.y

def release(e):
    pointer[0], pointer[1] = -1, -1

cv.bind("<B1-Motion>", touch)
cv.bind("<Button-1>", touch)
cv.bind("<ButtonRelease-1>", release)

def loop():
    cv.delete("all")
    bw = W / BARS
    for i in range(BARS):
        base = 90 + 70 * math.sin(phase[0] + i * 0.25) + 45 * math.cos(phase[0] * 1.7 - i * 0.4)
        target = max(15, base + random.randint(-20, 25))
        if pointer[0] >= 0:
            dist = abs((i + 0.5) * bw - pointer[0])
            if dist < 95:
                boost = (1 - dist / 95) * (H - pointer[1])
                target = max(target, boost)
        levels[i] += (target - levels[i]) * 0.28
        if levels[i] > peaks[i]:
            peaks[i] = levels[i]
        else:
            peaks[i] = max(levels[i], peaks[i] - 2.5)

        r, g, b = colorsys.hsv_to_rgb(i / BARS, 0.95, 1.0)
        col = f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
        x1 = i * bw + 3
        x2 = (i + 1) * bw - 3
        cv.create_rectangle(x1, H - levels[i], x2, H - 10, fill=col, outline="")
        cv.create_rectangle(x1, H - peaks[i] - 5, x2, H - peaks[i], fill="#ffffff", outline="")

    cv.create_text(15, 18, text="AUDIO FREQUENCY SPECTRUM  |  TOUCH / DRAG TO BOOST BANDS",
                   fill="#00e5ff", anchor="w", font=("Consolas", 10, "bold"))
    phase[0] += 0.14
    root.after(25, loop)

loop()
root.mainloop()
