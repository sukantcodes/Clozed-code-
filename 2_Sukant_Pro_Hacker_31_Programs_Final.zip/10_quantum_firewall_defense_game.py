# 10. Touch-Interactive Cyber Firewall Defense Game (Click/Tap Red Threats to Destroy!)
import tkinter as tk
import random, math

root = tk.Tk()
root.title("QUANTUM FIREWALL DEFENSE // TAP OR CLICK RED THREATS!")
W, H = 720, 560
cv = tk.Canvas(root, width=W, height=H, bg="#04080f", highlightthickness=0)
cv.pack()

cx, cy = W // 2, H // 2
threats = []
effects = []
score = [0]
hp = [100]

def spawn():
    ang = random.uniform(0, 2 * math.pi)
    dist = 340
    threats.append({
        "x": cx + dist * math.cos(ang),
        "y": cy + dist * math.sin(ang),
        "spd": random.uniform(1.6, 3.2),
        "tag": random.choice(["TROJAN", "DDOS", "WORM", "SQLi", "XSS"])
    })

def on_tap(e):
    if hp[0] <= 0:
        hp[0] = 100
        score[0] = 0
        threats.clear()
        return
    for t in threats[:]:
        if math.hypot(t["x"] - e.x, t["y"] - e.y) < 34:
            threats.remove(t)
            score[0] += 10
            effects.append([t["x"], t["y"], 10])
            break

cv.bind("<Button-1>", on_tap)

def loop():
    cv.delete("all")
    if hp[0] > 0:
        if random.random() < 0.045:
            spawn()
        # Core
        cv.create_oval(cx - 34, cy - 34, cx + 34, cy + 34, outline="#00ff66", width=3)
        cv.create_text(cx, cy, text="CORE", fill="#00ff66", font=("Consolas", 11, "bold"))

        for t in threats[:]:
            dx, dy = cx - t["x"], cy - t["y"]
            d = math.hypot(dx, dy)
            if d < 36:
                threats.remove(t)
                hp[0] = max(0, hp[0] - 15)
                continue
            t["x"] += (dx / d) * t["spd"]
            t["y"] += (dy / d) * t["spd"]
            cv.create_line(cx, cy, t["x"], t["y"], fill="#330812", dash=(2, 4))
            cv.create_oval(t["x"] - 14, t["y"] - 14, t["x"] + 14, t["y"] + 14, fill="#ff1744", outline="#fff")
            cv.create_text(t["x"], t["y"] - 20, text=t["tag"], fill="#ff8a80", font=("Consolas", 8, "bold"))

        for ef in effects[:]:
            cv.create_oval(ef[0] - ef[2], ef[1] - ef[2], ef[0] + ef[2], ef[1] + ef[2], outline="#00e5ff", width=2)
            ef[2] += 4
            if ef[2] > 42:
                effects.remove(ef)

        cv.create_text(16, 20, text=f"FIREWALL INTEGRITY: {hp[0]}%   |   THREATS NEUTRALIZED: {score[0]}",
                       fill="#00ff66", anchor="w", font=("Consolas", 11, "bold"))
    else:
        cv.create_text(cx, cy - 20, text="SYSTEM BREACHED!", fill="#ff1744", font=("Consolas", 28, "bold"))
        cv.create_text(cx, cy + 20, text=f"FINAL SCORE: {score[0]}  |  CLICK ANYWHERE TO REBOOT",
                       fill="#00e5ff", font=("Consolas", 13, "bold"))
    root.after(25, loop)

loop()
root.mainloop()
