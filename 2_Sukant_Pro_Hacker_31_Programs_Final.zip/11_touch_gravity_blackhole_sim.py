# 11. Touch-Interactive Black Hole Gravity Simulator (Hold & Drag to Pull 250 Stars!)
import tkinter as tk
import random, math, colorsys

root = tk.Tk()
root.title("BLACK HOLE GRAVITY WELL // HOLD & DRAG TO BEND SPACE!")
W, H = 820, 560
cv = tk.Canvas(root, width=W, height=H, bg="#020207", highlightthickness=0)
cv.pack()

particles = []
for i in range(240):
    r, g, b = colorsys.hsv_to_rgb(random.uniform(0.5, 0.9), 0.85, 1.0)
    col = f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
    particles.append([random.uniform(0, W), random.uniform(0, H),
                      random.uniform(-1.5, 1.5), random.uniform(-1.5, 1.5), col])

well = [W / 2, H / 2, False]

def on_press(e):
    well[0], well[1], well[2] = e.x, e.y, True

def on_release(e):
    well[2] = False

cv.bind("<Button-1>", on_press)
cv.bind("<B1-Motion>", on_press)
cv.bind("<ButtonRelease-1>", on_release)

def step():
    cv.delete("all")
    if well[2]:
        cv.create_oval(well[0] - 22, well[1] - 22, well[0] + 22, well[1] + 22, outline="#ff4081", width=2)
        cv.create_oval(well[0] - 10, well[1] - 10, well[0] + 10, well[1] + 10, fill="#000", outline="#fff")

    for p in particles:
        if well[2]:
            dx = well[0] - p[0]
            dy = well[1] - p[1]
            dist = max(25.0, math.hypot(dx, dy))
            force = 180.0 / (dist * dist)
            p[2] += dx * force
            p[3] += dy * force
        p[2] *= 0.992
        p[3] *= 0.992
        p[0] = (p[0] + p[2]) % W
        p[1] = (p[1] + p[3]) % H
        cv.create_oval(p[0] - 2, p[1] - 2, p[0] + 2, p[1] + 2, fill=p[4], outline="")

    cv.create_text(14, 18, text="HOLD & DRAG ANYWHERE TO CREATE A BLACK HOLE GRAVITY WELL",
                   fill="#00e5ff", anchor="w", font=("Consolas", 10, "bold"))
    root.after(20, step)

step()
root.mainloop()
