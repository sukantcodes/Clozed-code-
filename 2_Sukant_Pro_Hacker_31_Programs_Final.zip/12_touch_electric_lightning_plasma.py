# 12. Interactive Tesla Coil / Plasma Ball (Touch & Drag to Pull Real-Time Lightning!)
import tkinter as tk
import random, math

root = tk.Tk()
root.title("TESLA PLASMA BALL // TOUCH & DRAG TO ATTRACT LIGHTNING!")
W, H = 760, 560
cv = tk.Canvas(root, width=W, height=H, bg="#03020a", highlightthickness=0)
cv.pack()

cx, cy = W // 2, H // 2
target = [cx, cy, False]

def move_touch(e):
    target[0], target[1], target[2] = e.x, e.y, True

def end_touch(e):
    target[2] = False

cv.bind("<Button-1>", move_touch)
cv.bind("<B1-Motion>", move_touch)
cv.bind("<ButtonRelease-1>", end_touch)

def draw_bolt(x1, y1, x2, y2, depth, col):
    if depth == 0:
        cv.create_line(x1, y1, x2, y2, fill=col, width=2)
        return
    mx = (x1 + x2) / 2 + random.uniform(-22, 22) * (depth / 4)
    my = (y1 + y2) / 2 + random.uniform(-22, 22) * (depth / 4)
    draw_bolt(x1, y1, mx, my, depth - 1, col)
    draw_bolt(mx, my, x2, y2, depth - 1, col)

def loop():
    cv.delete("all")
    cv.create_oval(cx - 240, cy - 240, cx + 240, cy + 240, outline="#2a0a4a", width=3)
    cv.create_oval(cx - 28, cy - 28, cx + 28, cy + 28, fill="#aa00ff", outline="#00e5ff", width=2)

    if target[2]:
        for col in ("#aa00ff", "#00e5ff", "#ffffff"):
            draw_bolt(cx, cy, target[0], target[1], 4, col)
        cv.create_oval(target[0] - 12, target[1] - 12, target[0] + 12, target[1] + 12, outline="#00e5ff", width=2)
    else:
        for _ in range(5):
            a = random.uniform(0, 2 * math.pi)
            draw_bolt(cx, cy, cx + 235 * math.cos(a), cy + 235 * math.sin(a), 3, random.choice(["#d500f9", "#00e5ff"]))

    cv.create_text(14, 18, text="TOUCH OR DRAG ANYWHERE TO CONDUCT HIGH-VOLTAGE PLASMA ARCS",
                   fill="#e040fb", anchor="w", font=("Consolas", 10, "bold"))
    root.after(45, loop)

loop()
root.mainloop()
