# 13. Touch-Interactive Neon Silk & Plasma Ribbons (Drag Finger/Mouse to Paint!)
import tkinter as tk
import colorsys

root = tk.Tk()
root.title("NEON SILK RIBBONS // DRAG TO PAINT GLOWING PLASMA")
W, H = 820, 560
cv = tk.Canvas(root, width=W, height=H, bg="#040408", highlightthickness=0)
cv.pack()

trails = []
hue = [0.0]
last = [None, None]

def on_drag(e):
    if last[0] is not None:
        hue[0] = (hue[0] + 0.012) % 1.0
        for sym_x, sym_y in [(1, 1), (-1, 1), (1, -1), (-1, -1)]:
            x1 = W / 2 + (last[0] - W / 2) * sym_x
            y1 = H / 2 + (last[1] - H / 2) * sym_y
            x2 = W / 2 + (e.x - W / 2) * sym_x
            y2 = H / 2 + (e.y - H / 2) * sym_y
            trails.append([x1, y1, x2, y2, hue[0], 1.0])
    last[0], last[1] = e.x, e.y

def on_release(e):
    last[0], last[1] = None, None

cv.bind("<B1-Motion>", on_drag)
cv.bind("<ButtonRelease-1>", on_release)

def animate():
    cv.delete("all")
    for t in trails[:]:
        t[5] -= 0.025
        if t[5] <= 0.05:
            trails.remove(t)
            continue
        r, g, b = colorsys.hsv_to_rgb(t[4], 1.0, t[5])
        col = f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
        cv.create_line(t[0], t[1], t[2], t[3], fill=col, width=max(1, int(t[5] * 5)), capstyle="round")
    cv.create_text(14, 18, text="DRAG TO PAINT 4-WAY SYMMETRIC NEON PLASMA RIBBONS",
                   fill="#00e5ff", anchor="w", font=("Consolas", 10, "bold"))
    root.after(20, animate)

animate()
root.mainloop()
