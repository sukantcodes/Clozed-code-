# 14. Touch-Interactive Conway's Game of Life (Draw Cells with Mouse/Touch!)
import tkinter as tk
import random

root = tk.Tk()
root.title("CONWAY'S GAME OF LIFE // DRAW CELLS & PRESS START")
root.configure(bg="#080c12")

ROWS, COLS, CELL = 32, 48, 15
grid = [[1 if random.random() < 0.22 else 0 for _ in range(COLS)] for _ in range(ROWS)]
running = [True]

cv = tk.Canvas(root, width=COLS * CELL, height=ROWS * CELL, bg="#04070c", highlightthickness=0)
cv.pack(padx=6, pady=6)

def paint_cell(e):
    c, r = e.x // CELL, e.y // CELL
    if 0 <= r < ROWS and 0 <= c < COLS:
        grid[r][c] = 1
        draw()

cv.bind("<Button-1>", paint_cell)
cv.bind("<B1-Motion>", paint_cell)

def draw():
    cv.delete("all")
    for r in range(ROWS):
        for c in range(COLS):
            if grid[r][c]:
                cv.create_rectangle(c * CELL + 1, r * CELL + 1, (c + 1) * CELL - 1, (r + 1) * CELL - 1,
                                    fill="#00ff88", outline="")

def step():
    global grid
    if running[0]:
        nxt = [[0] * COLS for _ in range(ROWS)]
        for r in range(ROWS):
            for c in range(COLS):
                n = sum(grid[(r + dr) % ROWS][(c + dc) % COLS]
                        for dr in (-1, 0, 1) for dc in (-1, 0, 1) if (dr or dc))
                if grid[r][c] and n in (2, 3):
                    nxt[r][c] = 1
                elif not grid[r][c] and n == 3:
                    nxt[r][c] = 1
        grid = nxt
        draw()
    root.after(80, step)

bf = tk.Frame(root, bg="#080c12")
bf.pack(pady=4)
tk.Button(bf, text="PAUSE / PLAY", bg="#0d2b1d", fg="#00ff88", font=("Consolas", 10, "bold"),
          command=lambda: running.__setitem__(0, not running[0])).pack(side="left", padx=6)
tk.Button(bf, text="RANDOMIZE", bg="#0d1f33", fg="#00e5ff", font=("Consolas", 10, "bold"),
          command=lambda: [grid.__setitem__(r, [1 if random.random() < 0.25 else 0 for _ in range(COLS)]) for r in range(ROWS)] or draw()).pack(side="left", padx=6)
tk.Button(bf, text="CLEAR", bg="#330d15", fg="#ff5252", font=("Consolas", 10, "bold"),
          command=lambda: [grid.__setitem__(r, [0] * COLS) for r in range(ROWS)] or draw()).pack(side="left", padx=6)

draw()
step()
root.mainloop()
