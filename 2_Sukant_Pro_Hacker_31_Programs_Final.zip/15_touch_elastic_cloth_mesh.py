# 15. Touch-Interactive Elastic Cyber Grid Mesh (Drag Across Grid to Stretch & Ripple!)
import tkinter as tk
import math

root = tk.Tk()
root.title("ELASTIC CYBER MESH // DRAG TO WARP & RIPPLE GRID!")
W, H = 760, 520
cv = tk.Canvas(root, width=W, height=H, bg="#050810", highlightthickness=0)
cv.pack()

COLS, ROWS = 18, 12
SPACING = 38
OX = (W - (COLS - 1) * SPACING) / 2
OY = (H - (ROWS - 1) * SPACING) / 2

# [x, y, ox, oy, vx, vy]
pts = [[[OX + c * SPACING, OY + r * SPACING, OX + c * SPACING, OY + r * SPACING, 0.0, 0.0]
        for c in range(COLS)] for r in range(ROWS)]

def push(e):
    for r in range(ROWS):
        for c in range(COLS):
            p = pts[r][c]
            dx, dy = p[0] - e.x, p[1] - e.y
            d = math.hypot(dx, dy)
            if 1 < d < 95:
                f = (95 - d) * 0.16
                p[4] += (dx / d) * f
                p[5] += (dy / d) * f

cv.bind("<B1-Motion>", push)
cv.bind("<Motion>", push)

def update():
    cv.delete("all")
    for r in range(ROWS):
        for c in range(COLS):
            p = pts[r][c]
            p[4] = (p[4] + (p[2] - p[0]) * 0.08) * 0.86
            p[5] = (p[5] + (p[3] - p[1]) * 0.08) * 0.86
            p[0] += p[4]
            p[1] += p[5]

    for r in range(ROWS):
        for c in range(COLS):
            x, y = pts[r][c][0], pts[r][c][1]
            if c + 1 < COLS:
                cv.create_line(x, y, pts[r][c + 1][0], pts[r][c + 1][1], fill="#00e5ff", width=1)
            if r + 1 < ROWS:
                cv.create_line(x, y, pts[r + 1][c][0], pts[r + 1][c][1], fill="#00ff88", width=1)

    cv.create_text(14, 18, text="MOVE OR DRAG ACROSS THE MESH TO WARP ELASTIC SPACE-TIME",
                   fill="#00ff88", anchor="w", font=("Consolas", 10, "bold"))
    root.after(20, update)

update()
root.mainloop()
