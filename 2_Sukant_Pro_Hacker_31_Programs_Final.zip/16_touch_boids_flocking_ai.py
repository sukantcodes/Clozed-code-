# 16. Interactive AI Swarm / Boids Flocking Simulation (Hold/Drag to Lead the Drone Swarm!)
import tkinter as tk
import random, math

root = tk.Tk()
root.title("AI SWARM FLOCKING // HOLD & DRAG TO COMMAND DRONES")
W, H = 820, 540
cv = tk.Canvas(root, width=W, height=H, bg="#04070e", highlightthickness=0)
cv.pack()

boids = [[random.uniform(0, W), random.uniform(0, H), random.uniform(-3, 3), random.uniform(-3, 3)]
         for _ in range(65)]
leader = [W / 2, H / 2, False]

def set_leader(e):
    leader[0], leader[1], leader[2] = e.x, e.y, True

cv.bind("<Button-1>", set_leader)
cv.bind("<B1-Motion>", set_leader)
cv.bind("<ButtonRelease-1>", lambda e: leader.__setitem__(2, False))

def loop():
    cv.delete("all")
    if leader[2]:
        cv.create_oval(leader[0] - 12, leader[1] - 12, leader[0] + 12, leader[1] + 12, outline="#ffd600", width=2)

    for b in boids:
        ax = ay = cx = cy = sx = sy = count = 0
        for o in boids:
            if o is b:
                continue
            dx, dy = o[0] - b[0], o[1] - b[1]
            d = math.hypot(dx, dy)
            if d < 55:
                cx += o[0]; cy += o[1]
                ax += o[2]; ay += o[3]
                if d < 20 and d > 0:
                    sx -= dx / d; sy -= dy / d
                count += 1
        if count:
            b[2] += ((cx / count - b[0]) * 0.005) + ((ax / count - b[2]) * 0.05) + sx * 0.25
            b[3] += ((cy / count - b[1]) * 0.005) + ((ay / count - b[3]) * 0.05) + sy * 0.25
        if leader[2]:
            b[2] += (leader[0] - b[0]) * 0.004
            b[3] += (leader[1] - b[1]) * 0.004
        spd = math.hypot(b[2], b[3])
        if spd > 4.5:
            b[2] = (b[2] / spd) * 4.5
            b[3] = (b[3] / spd) * 4.5
        b[0] = (b[0] + b[2]) % W
        b[1] = (b[1] + b[3]) % H

        ang = math.atan2(b[3], b[2])
        p1 = (b[0] + 9 * math.cos(ang), b[1] + 9 * math.sin(ang))
        p2 = (b[0] + 6 * math.cos(ang + 2.4), b[1] + 6 * math.sin(ang + 2.4))
        p3 = (b[0] + 6 * math.cos(ang - 2.4), b[1] + 6 * math.sin(ang - 2.4))
        cv.create_polygon(*p1, *p2, *p3, fill="#00e5ff", outline="")

    cv.create_text(14, 18, text="AUTONOMOUS AI SWARM (65 DRONES)  |  HOLD & DRAG TO ATTRACT",
                   fill="#00e5ff", anchor="w", font=("Consolas", 10, "bold"))
    root.after(22, loop)

loop()
root.mainloop()
