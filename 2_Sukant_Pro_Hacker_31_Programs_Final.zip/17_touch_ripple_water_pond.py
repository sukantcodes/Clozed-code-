# 17. Touch-Interactive Neon Water Ripple Interference Waves (Tap/Drag Anywhere!)
import tkinter as tk
import colorsys, random

root = tk.Tk()
root.title("NEON RIPPLE INTERFERENCE // TAP OR DRAG ANYWHERE!")
W, H = 800, 540
cv = tk.Canvas(root, width=W, height=H, bg="#03060c", highlightthickness=0)
cv.pack()

ripples = []

def add_ripple(e):
    ripples.append([e.x, e.y, 6.0, random.random()])

cv.bind("<Button-1>", add_ripple)
cv.bind("<B1-Motion>", lambda e: add_ripple(e) if random.random() < 0.35 else None)

def animate():
    cv.delete("all")
    if random.random() < 0.04:
        ripples.append([random.randint(60, W - 60), random.randint(60, H - 60), 6.0, random.random()])
    for rp in ripples[:]:
        rp[2] += 3.5
        alpha = max(0.0, 1.0 - rp[2] / 210.0)
        if alpha <= 0.04:
            ripples.remove(rp)
            continue
        r, g, b = colorsys.hsv_to_rgb(rp[3], 1.0, alpha)
        col = f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
        rad = rp[2]
        cv.create_oval(rp[0] - rad, rp[1] - rad, rp[0] + rad, rp[1] + rad, outline=col, width=2)

    cv.create_text(14, 18, text="TAP OR DRAG ANYWHERE TO LAUNCH NEON RIPPLE WAVES",
                   fill="#00e5ff", anchor="w", font=("Consolas", 10, "bold"))
    root.after(22, animate)

animate()
root.mainloop()
