# 18. Real-Time Touch-Controlled Fractal Tree Morpher (Move/Drag to Bend Angles & Symmetry!)
import tkinter as tk
import math, colorsys

root = tk.Tk()
root.title("REAL-TIME FRACTAL TREE MORPHER // MOVE OR DRAG TO MORPH!")
W, H = 800, 560
cv = tk.Canvas(root, width=W, height=H, bg="#05070c", highlightthickness=0)
cv.pack()

def draw_branch(x, y, length, angle, spread, wind, depth):
    if depth == 0:
        return
    x2 = x + length * math.cos(angle)
    y2 = y - length * math.sin(angle)
    r, g, b = colorsys.hsv_to_rgb(depth / 10.0, 0.9, 1.0)
    col = f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
    cv.create_line(x, y, x2, y2, fill=col, width=max(1, depth - 2))
    draw_branch(x2, y2, length * 0.74, angle + spread + wind, spread, wind, depth - 1)
    draw_branch(x2, y2, length * 0.74, angle - spread + wind, spread, wind, depth - 1)

def render(mx, my):
    cv.delete("all")
    spread = 0.15 + (my / H) * 1.15
    wind = ((mx - W / 2) / (W / 2)) * 0.45
    draw_branch(W / 2, H - 30, 125, math.pi / 2, spread, wind, 9)
    cv.create_text(14, 18, text=f"ANGLE: {math.degrees(spread):.1f}°  |  WIND: {wind:+.2f}  |  DRAG TO MORPH TREE",
                   fill="#00ff88", anchor="w", font=("Consolas", 10, "bold"))

cv.bind("<Motion>", lambda e: render(e.x, e.y))
cv.bind("<B1-Motion>", lambda e: render(e.x, e.y))
render(W / 2, H / 3)
root.mainloop()
