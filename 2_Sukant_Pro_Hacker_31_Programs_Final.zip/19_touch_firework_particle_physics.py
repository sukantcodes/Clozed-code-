# 19. Touch-Triggered Physics Fireworks Engine (Tap Anywhere to Launch Multi-Spark Explosions!)
import tkinter as tk
import random, math, colorsys

root = tk.Tk()
root.title("PHYSICS FIREWORKS ENGINE // TAP ANYWHERE TO DETONATE!")
W, H = 820, 560
cv = tk.Canvas(root, width=W, height=H, bg="#04040a", highlightthickness=0)
cv.pack()

sparks = []

def explode(x, y):
    base_hue = random.random()
    for _ in range(55):
        ang = random.uniform(0, 2 * math.pi)
        spd = random.uniform(1.5, 6.5)
        sparks.append([x, y, math.cos(ang) * spd, math.sin(ang) * spd, (base_hue + random.uniform(-0.08, 0.08)) % 1.0, 1.0])

cv.bind("<Button-1>", lambda e: explode(e.x, e.y))
cv.bind("<B1-Motion>", lambda e: explode(e.x, e.y) if random.random() < 0.2 else None)

def loop():
    cv.delete("all")
    if random.random() < 0.03:
        explode(random.randint(100, W - 100), random.randint(80, H - 200))
    for s in sparks[:]:
        s[0] += s[2]
        s[1] += s[3]
        s[3] += 0.12  # gravity
        s[2] *= 0.98
        s[5] -= 0.022
        if s[5] <= 0.05:
            sparks.remove(s)
            continue
        r, g, b = colorsys.hsv_to_rgb(s[4], 1.0, s[5])
        col = f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
        cv.create_oval(s[0] - 2.5, s[1] - 2.5, s[0] + 2.5, s[1] + 2.5, fill=col, outline="")

    cv.create_text(14, 18, text="TAP OR DRAG ANYWHERE TO LAUNCH GRAVITY FIREWORKS",
                   fill="#ffd600", anchor="w", font=("Consolas", 10, "bold"))
    root.after(20, loop)

loop()
root.mainloop()
