# 20. Interactive Cyber Constellation Particle Web (Move/Touch to Connect Laser Nodes!)
import tkinter as tk
import random, math

root = tk.Tk()
root.title("CYBER CONSTELLATION WEB // TOUCH OR MOVE TO CONNECT NODES")
W, H = 840, 540
cv = tk.Canvas(root, width=W, height=H, bg="#040710", highlightthickness=0)
cv.pack()

nodes = [[random.uniform(0, W), random.uniform(0, H), random.uniform(-1.6, 1.6), random.uniform(-1.6, 1.6)]
         for _ in range(65)]
mouse = [W / 2, H / 2]

cv.bind("<Motion>", lambda e: (mouse.__setitem__(0, e.x), mouse.__setitem__(1, e.y)))
cv.bind("<B1-Motion>", lambda e: (mouse.__setitem__(0, e.x), mouse.__setitem__(1, e.y)))

def loop():
    cv.delete("all")
    for n in nodes:
        n[0] += n[2]
        n[1] += n[3]
        if n[0] < 0 or n[0] > W: n[2] *= -1
        if n[1] < 0 or n[1] > H: n[3] *= -1

    for i, a in enumerate(nodes):
        dm = math.hypot(a[0] - mouse[0], a[1] - mouse[1])
        if dm < 145:
            cv.create_line(a[0], a[1], mouse[0], mouse[1], fill="#ff4081", width=1)
        for j in range(i + 1, len(nodes)):
            b = nodes[j]
            d = math.hypot(a[0] - b[0], a[1] - b[1])
            if d < 105:
                cv.create_line(a[0], a[1], b[0], b[1], fill="#00b0ff", width=1)
        cv.create_oval(a[0] - 2.5, a[1] - 2.5, a[0] + 2.5, a[1] + 2.5, fill="#00ff88", outline="")

    cv.create_oval(mouse[0] - 5, mouse[1] - 5, mouse[0] + 5, mouse[1] + 5, fill="#ff4081", outline="#fff")
    cv.create_text(14, 18, text="INTERACTIVE NEURAL CONSTELLATION WEB  |  MOVE OR TOUCH SCREEN",
                   fill="#00e5ff", anchor="w", font=("Consolas", 10, "bold"))
    root.after(22, loop)

loop()
root.mainloop()
