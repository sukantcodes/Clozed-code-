# 21. 4D Rotating Hypercube (Tesseract) Projection (Drag to Rotate 4D Space!)
import tkinter as tk
import math

root = tk.Tk()
root.title("4D HYPERCUBE (TESSERACT) // DRAG TO ROTATE IN 4TH DIMENSION!")
W, H = 700, 560
cv = tk.Canvas(root, width=W, height=H, bg="#03050a", highlightthickness=0)
cv.pack()

verts = [[x, y, z, w] for x in (-1, 1) for y in (-1, 1) for z in (-1, 1) for w in (-1, 1)]
edges = [(i, j) for i in range(16) for j in range(i + 1, 16)
         if sum(verts[i][k] != verts[j][k] for k in range(4)) == 1]

ang = [0.0, 0.0]
last = [None, None]

def drag(e):
    if last[0] is not None:
        ang[0] += (e.x - last[0]) * 0.01
        ang[1] += (e.y - last[1]) * 0.01
    last[0], last[1] = e.x, e.y

cv.bind("<B1-Motion>", drag)
cv.bind("<ButtonRelease-1>", lambda e: (last.__setitem__(0, None), last.__setitem__(1, None)))

def loop():
    cv.delete("all")
    a, b = ang[0], ang[1]
    proj = []
    for x, y, z, w in verts:
        # 4D XW and ZW rotations
        x1 = x * math.cos(a) - w * math.sin(a)
        w1 = x * math.sin(a) + w * math.cos(a)
        z1 = z * math.cos(b) - w1 * math.sin(b)
        w2 = z * math.sin(b) + w1 * math.cos(b)
        # 4D -> 3D -> 2D perspective
        d4 = 2.6 / (3.2 - w2)
        x3, y3, z3 = x1 * d4, y * d4, z1 * d4
        # Slight 3D tilt
        yr = y3 * math.cos(0.4) - z3 * math.sin(0.4)
        zr = y3 * math.sin(0.4) + z3 * math.cos(0.4)
        d3 = 210 / (3.8 - zr)
        proj.append((W / 2 + x3 * d3, H / 2 + yr * d3, w2))

    for i, j in edges:
        x1, y1, w1 = proj[i]
        x2, y2, w2 = proj[j]
        col = "#00e5ff" if (w1 + w2) > 0 else "#d500f9"
        cv.create_line(x1, y1, x2, y2, fill=col, width=2)

    cv.create_text(14, 18, text="4-DIMENSIONAL TESSERACT PROJECTION  |  DRAG TO ROTATE 4D AXES",
                   fill="#00e5ff", anchor="w", font=("Consolas", 10, "bold"))
    ang[0] += 0.022
    ang[1] += 0.015
    root.after(22, loop)

loop()
root.mainloop()
