# 22. Interactive 3D Rotating Spiral Galaxy (Drag to Orbit 3D Camera!)
import tkinter as tk
import math, random, colorsys

root = tk.Tk()
root.title("3D SPIRAL GALAXY // DRAG TO ORBIT CAMERA IN 3D!")
W, H = 800, 560
cv = tk.Canvas(root, width=W, height=H, bg="#020206", highlightthickness=0)
cv.pack()

stars = []
arms = 4
for i in range(420):
    arm = i % arms
    r = random.uniform(8, 220)
    theta = (arm / arms) * 2 * math.pi + r * 0.032 + random.uniform(-0.35, 0.35)
    x = r * math.cos(theta)
    z = r * math.sin(theta)
    y = random.gauss(0, 14 * (1 - r / 260))
    hue = 0.55 + (r / 220) * 0.28
    cr, cg, cb = colorsys.hsv_to_rgb(hue % 1.0, 0.75, 1.0)
    col = f"#{int(cr*255):02x}{int(cg*255):02x}{int(cb*255):02x}"
    stars.append((x, y, z, col))

yaw, pitch = [0.0], [0.65]
last = [None, None]

def drag(e):
    if last[0] is not None:
        yaw[0] += (e.x - last[0]) * 0.01
        pitch[0] = max(-1.4, min(1.4, pitch[0] + (e.y - last[1]) * 0.01))
    last[0], last[1] = e.x, e.y

cv.bind("<B1-Motion>", drag)
cv.bind("<ButtonRelease-1>", lambda e: (last.__setitem__(0, None), last.__setitem__(1, None)))

def loop():
    cv.delete("all")
    cy, sy = math.cos(yaw[0]), math.sin(yaw[0])
    cp, sp = math.cos(pitch[0]), math.sin(pitch[0])
    for x, y, z, col in stars:
        x1 = x * cy - z * sy
        z1 = x * sy + z * cy
        y2 = y * cp - z1 * sp
        z2 = y * sp + z1 * cp
        scale = 420 / (z2 + 460)
        sx, sy_p = W / 2 + x1 * scale, H / 2 + y2 * scale
        sz = max(1, int(2.6 * scale))
        cv.create_oval(sx - sz, sy_p - sz, sx + sz, sy_p + sz, fill=col, outline="")

    cv.create_text(14, 18, text="3D SPIRAL GALAXY (420 STARS)  |  DRAG TO TILT & ORBIT CAMERA",
                   fill="#80d8ff", anchor="w", font=("Consolas", 10, "bold"))
    yaw[0] += 0.012
    root.after(25, loop)

loop()
root.mainloop()
