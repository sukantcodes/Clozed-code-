# 23. Synthwave 3D Infinite Scrolling Cyber-Terrain Grid
import tkinter as tk
import math

root = tk.Tk()
root.title("SYNTHWAVE 3D CYBER TERRAIN")
W, H = 820, 520
cv = tk.Canvas(root, width=W, height=H, bg="#090214", highlightthickness=0)
cv.pack()

offset = [0.0]

def project(x, y, z):
    scale = 340 / max(1.0, z)
    return W / 2 + x * scale, H * 0.56 - y * scale

def loop():
    cv.delete("all")
    # Retro Sun
    cv.create_oval(W / 2 - 90, 50, W / 2 + 90, 230, fill="#ff1744", outline="#ffd600", width=2)
    for y in range(130, 230, 14):
        cv.create_line(W / 2 - 95, y, W / 2 + 95, y, fill="#090214", width=4)

    cols, rows = 20, 18
    grid_pts = []
    for r in range(rows):
        z = 4.0 + r * 1.4 - (offset[0] % 1.4)
        row_pts = []
        for c in range(-cols // 2, cols // 2 + 1):
            wx = c * 2.2
            wz = r + int(offset[0] / 1.4)
            valley = abs(c) * 0.35
            wy = -4.5 + valley * (math.sin(wx * 0.6 + wz * 0.5) + math.cos(wz * 0.4)) * 0.9
            row_pts.append(project(wx, wy, z))
        grid_pts.append(row_pts)

    for r in range(rows - 1):
        for c in range(len(grid_pts[r]) - 1):
            x1, y1 = grid_pts[r][c]
            x2, y2 = grid_pts[r][c + 1]
            x3, y3 = grid_pts[r + 1][c]
            cv.create_line(x1, y1, x2, y2, fill="#00e5ff", width=1)
            cv.create_line(x1, y1, x3, y3, fill="#d500f9", width=1)

    offset[0] += 0.14
    root.after(28, loop)

loop()
root.mainloop()
