# 24. Interactive Mandelbrot Fractal Zoomer (Click/Touch Any Spot to Zoom In Deeper!)
import tkinter as tk
import colorsys

root = tk.Tk()
root.title("MANDELBROT FRACTAL EXPLORER // CLICK ANYWHERE TO ZOOM IN!")
W, H = 440, 340
cv = tk.Canvas(root, width=W, height=H, bg="black", highlightthickness=0)
cv.pack()

img = tk.PhotoImage(width=W, height=H)
cv.create_image((W // 2, H // 2), image=img, state="normal")

view = [-2.2, 1.0, -1.25, 1.25]  # xmin, xmax, ymin, ymax
zoom_lvl = [1]

def render():
    xmin, xmax, ymin, ymax = view
    max_iter = 32 + zoom_lvl[0] * 6
    rows = []
    for py in range(H):
        y0 = ymin + (py / H) * (ymax - ymin)
        row_cols = []
        for px in range(W):
            x0 = xmin + (px / W) * (xmax - xmin)
            x = y = 0.0
            it = 0
            while x * x + y * y <= 4.0 and it < max_iter:
                x, y = x * x - y * y + x0, 2 * x * y + y0
                it += 1
            if it == max_iter:
                row_cols.append("#000000")
            else:
                r, g, b = colorsys.hsv_to_rgb((it / max_iter * 2.5 + 0.55) % 1.0, 0.95, 1.0)
                row_cols.append(f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}")
        rows.append("{" + " ".join(row_cols) + "}")
    img.put(" ".join(rows))
    root.title(f"MANDELBROT FRACTAL // ZOOM x{2**(zoom_lvl[0]-1)} (CLICK TO ZOOM)")

def zoom(e):
    xmin, xmax, ymin, ymax = view
    cx = xmin + (e.x / W) * (xmax - xmin)
    cy = ymin + (e.y / H) * (ymax - ymin)
    dx = (xmax - xmin) * 0.25
    dy = (ymax - ymin) * 0.25
    view[:] = [cx - dx, cx + dx, cy - dy, cy + dy]
    zoom_lvl[0] += 1
    render()

cv.bind("<Button-1>", zoom)
render()
root.mainloop()
