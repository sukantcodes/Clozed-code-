# 25. Double Pendulum Chaos Physics Simulator (Click Anywhere to Reset with New Chaos!)
import tkinter as tk
import math, random, colorsys

root = tk.Tk()
root.title("CHAOS PHYSICS: DOUBLE PENDULUM // CLICK TO RANDOMIZE")
W, H = 720, 560
cv = tk.Canvas(root, width=W, height=H, bg="#04060c", highlightthickness=0)
cv.pack()

ox, oy = W / 2, 200
L1, L2, m1, m2, g = 140.0, 140.0, 12.0, 12.0, 0.65
state = [math.pi / 2 + 0.4, math.pi / 2, 0.0, 0.0]
trail = []
hue = [0.0]

def reset(e=None):
    state[:] = [random.uniform(1.2, 2.8), random.uniform(1.0, 3.0), 0.0, 0.0]
    trail.clear()

cv.bind("<Button-1>", reset)

def loop():
    a1, a2, v1, v2 = state
    num1 = -g * (2 * m1 + m2) * math.sin(a1)
    num2 = -m2 * g * math.sin(a1 - 2 * a2)
    num3 = -2 * math.sin(a1 - a2) * m2 * (v2 * v2 * L2 + v1 * v1 * L1 * math.cos(a1 - a2))
    den = L1 * (2 * m1 + m2 - m2 * math.cos(2 * a1 - 2 * a2))
    acc1 = (num1 + num2 + num3) / den

    num4 = 2 * math.sin(a1 - a2) * (v1 * v1 * L1 * (m1 + m2) + g * (m1 + m2) * math.cos(a1) + v2 * v2 * L2 * m2 * math.cos(a1 - a2))
    den2 = L2 * (2 * m1 + m2 - m2 * math.cos(2 * a1 - 2 * a2))
    acc2 = num4 / den2

    v1 = (v1 + acc1) * 0.9995
    v2 = (v2 + acc2) * 0.9995
    a1 += v1
    a2 += v2
    state[:] = [a1, a2, v1, v2]

    x1, y1 = ox + L1 * math.sin(a1), oy + L1 * math.cos(a1)
    x2, y2 = x1 + L2 * math.sin(a2), y1 + L2 * math.cos(a2)
    hue[0] = (hue[0] + 0.004) % 1.0
    trail.append((x2, y2, hue[0]))
    if len(trail) > 260:
        trail.pop(0)

    cv.delete("all")
    for i in range(1, len(trail)):
        r, gr, b = colorsys.hsv_to_rgb(trail[i][2], 1.0, i / len(trail))
        col = f"#{int(r*255):02x}{int(gr*255):02x}{int(b*255):02x}"
        cv.create_line(trail[i - 1][0], trail[i - 1][1], trail[i][0], trail[i][1], fill=col, width=2)

    cv.create_line(ox, oy, x1, y1, fill="#ffffff", width=3)
    cv.create_line(x1, y1, x2, y2, fill="#00e5ff", width=3)
    cv.create_oval(x1 - 8, y1 - 8, x1 + 8, y1 + 8, fill="#ff4081", outline="#fff")
    cv.create_oval(x2 - 8, y2 - 8, x2 + 8, y2 + 8, fill="#00ff88", outline="#fff")
    cv.create_text(14, 18, text="CHAOTIC DOUBLE PENDULUM  |  CLICK ANYWHERE TO RESTART",
                   fill="#00e5ff", anchor="w", font=("Consolas", 10, "bold"))
    root.after(18, loop)

loop()
root.mainloop()
