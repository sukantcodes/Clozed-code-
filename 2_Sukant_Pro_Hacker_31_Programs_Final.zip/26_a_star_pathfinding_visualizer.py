# 26. Interactive A* AI Pathfinding Visualizer (Draw Walls with Touch/Mouse, Click RUN A*!)
import tkinter as tk
import heapq

root = tk.Tk()
root.title("A* AI PATHFINDING VISUALIZER // DRAW WALLS THEN RUN!")
root.configure(bg="#070a10")

R, C, S = 22, 30, 22
START, END = (2, 2), (R - 3, C - 3)
walls = set()

cv = tk.Canvas(root, width=C * S, height=R * S, bg="#0a101a", highlightthickness=0)
cv.pack(padx=8, pady=8)

def draw_cell(r, c, col):
    cv.create_rectangle(c * S + 1, r * S + 1, (c + 1) * S - 1, (r + 1) * S - 1, fill=col, outline="#101a2a")

def redraw():
    cv.delete("all")
    for r in range(R):
        for c in range(C):
            col = "#0d1522"
            if (r, c) in walls: col = "#37474f"
            elif (r, c) == START: col = "#00ff88"
            elif (r, c) == END: col = "#ff1744"
            draw_cell(r, c, col)

def paint_wall(e):
    c, r = e.x // S, e.y // S
    if 0 <= r < R and 0 <= c < C and (r, c) not in (START, END):
        walls.add((r, c))
        draw_cell(r, c, "#37474f")

cv.bind("<Button-1>", paint_wall)
cv.bind("<B1-Motion>", paint_wall)

def run_astar():
    redraw()
    pq = [(0, START)]
    came = {}
    g = {START: 0}
    visited_order = []

    while pq:
        _, cur = heapq.heappop(pq)
        if cur == END:
            break
        if cur != START:
            visited_order.append(cur)
        for dr, dc in ((1, 0), (-1, 0), (0, 1), (0, -1)):
            nr, nc = cur[0] + dr, cur[1] + dc
            nxt = (nr, nc)
            if 0 <= nr < R and 0 <= nc < C and nxt not in walls:
                ng = g[cur] + 1
                if ng < g.get(nxt, 1e9):
                    g[nxt] = ng
                    f = ng + abs(nr - END[0]) + abs(nc - END[1])
                    heapq.heappush(pq, (f, nxt))
                    came[nxt] = cur

    path = []
    if END in came:
        cur = came[END]
        while cur != START:
            path.append(cur)
            cur = came[cur]
        path.reverse()

    def anim(idx=0):
        if idx < len(visited_order):
            draw_cell(*visited_order[idx], "#005b96")
            root.after(8, lambda: anim(idx + 1))
        else:
            for p in path:
                draw_cell(*p, "#ffd600")
    anim()

bf = tk.Frame(root, bg="#070a10")
bf.pack(pady=6)
tk.Button(bf, text="RUN A* AI", bg="#003d1f", fg="#00ff88", font=("Consolas", 11, "bold"),
          padx=14, command=run_astar).pack(side="left", padx=8)
tk.Button(bf, text="CLEAR WALLS", bg="#330d15", fg="#ff5252", font=("Consolas", 11, "bold"),
          padx=14, command=lambda: (walls.clear(), redraw())).pack(side="left", padx=8)

redraw()
root.mainloop()
