# 27. Live Cyber Sorting Algorithm Visualizer (QuickSort & BubbleSort Neon Bars!)
import tkinter as tk
import random, colorsys

root = tk.Tk()
root.title("ALGORITHM VISUALIZER // QUICKSORT & BUBBLESORT")
root.configure(bg="#06090f")

W, H = 780, 420
cv = tk.Canvas(root, width=W, height=H, bg="#05080f", highlightthickness=0)
cv.pack(padx=8, pady=8)

N = 65
arr = [random.randint(15, H - 30) for _ in range(N)]
gen = [None]

def draw(active=()):
    cv.delete("all")
    bw = W / N
    for i, val in enumerate(arr):
        if i in active:
            col = "#ffffff"
        else:
            r, g, b = colorsys.hsv_to_rgb((val / H) * 0.75 + 0.45, 0.9, 1.0)
            col = f"#{int(r*255):02x}{int(g*255):02x}{int(b*255):02x}"
        cv.create_rectangle(i * bw + 1, H - val, (i + 1) * bw - 1, H, fill=col, outline="")

def quicksort(lo, hi):
    if lo < hi:
        pivot = arr[hi]
        i = lo
        for j in range(lo, hi):
            yield (j, hi)
            if arr[j] < pivot:
                arr[i], arr[j] = arr[j], arr[i]
                i += 1
                yield (i, j)
        arr[i], arr[hi] = arr[hi], arr[i]
        yield (i, hi)
        yield from quicksort(lo, i - 1)
        yield from quicksort(i + 1, hi)

def bubblesort():
    for i in range(N):
        for j in range(N - i - 1):
            if arr[j] > arr[j + 1]:
                arr[j], arr[j + 1] = arr[j + 1], arr[j]
            yield (j, j + 1)

def step():
    if gen[0] is not None:
        try:
            active = next(gen[0])
            draw(active)
            root.after(12, step)
        except StopIteration:
            gen[0] = None
            draw()

def start(algo):
    random.shuffle(arr)
    gen[0] = quicksort(0, N - 1) if algo == "quick" else bubblesort()
    step()

bf = tk.Frame(root, bg="#06090f")
bf.pack(pady=6)
tk.Button(bf, text="RUN QUICKSORT", bg="#003d1f", fg="#00ff88", font=("Consolas", 11, "bold"),
          padx=14, command=lambda: start("quick")).pack(side="left", padx=8)
tk.Button(bf, text="RUN BUBBLESORT", bg="#002b44", fg="#00e5ff", font=("Consolas", 11, "bold"),
          padx=14, command=lambda: start("bubble")).pack(side="left", padx=8)

draw()
root.mainloop()
