# 28. Cyber Neon 2048 Game (Play with Arrow Keys OR On-Screen Touch Buttons!)
import tkinter as tk
import random

root = tk.Tk()
root.title("CYBER 2048 // ARROW KEYS OR TOUCH BUTTONS")
root.configure(bg="#070a10")

COLORS = {
    0: ("#111926", "#111926"), 2: ("#1b2a41", "#00e5ff"), 4: ("#1e3a5f", "#00ff88"),
    8: ("#004d40", "#69f0ae"), 16: ("#006064", "#18ffff"), 32: ("#311b92", "#b388ff"),
    64: ("#4a148c", "#ea80fc"), 128: ("#880e4f", "#ff80ab"), 256: ("#b71c1c", "#ff5252"),
    512: ("#e65100", "#ffd180"), 1024: ("#f57f17", "#ffff00"), 2048: ("#00c853", "#ffffff")
}

board = [[0] * 4 for _ in range(4)]
score = [0]

score_lbl = tk.Label(root, text="SCORE: 0", fg="#00ff88", bg="#070a10", font=("Consolas", 16, "bold"))
score_lbl.pack(pady=8)

grid_frame = tk.Frame(root, bg="#070a10")
grid_frame.pack(padx=12, pady=6)

cells = [[tk.Label(grid_frame, text="", width=5, height=2, font=("Consolas", 20, "bold"),
                   bg="#111926", fg="#fff", relief="flat") for _ in range(4)] for _ in range(4)]
for r in range(4):
    for c in range(4):
        cells[r][c].grid(row=r, column=c, padx=5, pady=5)

def spawn():
    empty = [(r, c) for r in range(4) for c in range(4) if board[r][c] == 0]
    if empty:
        r, c = random.choice(empty)
        board[r][c] = 4 if random.random() < 0.1 else 2

def compress_row(row):
    nums = [x for x in row if x]
    res = []
    i = 0
    while i < len(nums):
        if i + 1 < len(nums) and nums[i] == nums[i + 1]:
            res.append(nums[i] * 2)
            score[0] += nums[i] * 2
            i += 2
        else:
            res.append(nums[i])
            i += 1
    return res + [0] * (4 - len(res))

def render():
    score_lbl.config(text=f"SCORE: {score[0]}")
    for r in range(4):
        for c in range(4):
            v = board[r][c]
            bg, fg = COLORS.get(v, ("#00ff88", "#000000"))
            cells[r][c].config(text=str(v) if v else "", bg=bg, fg=fg)

def move(direction):
    old = [row[:] for row in board]
    if direction == "Left":
        for r in range(4): board[r] = compress_row(board[r])
    elif direction == "Right":
        for r in range(4): board[r] = compress_row(board[r][::-1])[::-1]
    elif direction == "Up":
        for c in range(4):
            col = compress_row([board[r][c] for r in range(4)])
            for r in range(4): board[r][c] = col[r]
    elif direction == "Down":
        for c in range(4):
            col = compress_row([board[r][c] for r in range(4)][::-1])[::-1]
            for r in range(4): board[r][c] = col[r]
    if board != old:
        spawn()
    render()

for key in ("Left", "Right", "Up", "Down"):
    root.bind(f"<{key}>", lambda e, k=key: move(k))

# Touch controls
ctrl = tk.Frame(root, bg="#070a10")
ctrl.pack(pady=8)
for txt, d in [("▲ UP", "Up"), ("◀ LEFT", "Left"), ("▼ DOWN", "Down"), ("▶ RIGHT", "Right")]:
    tk.Button(ctrl, text=txt, bg="#102030", fg="#00e5ff", font=("Consolas", 10, "bold"),
              padx=10, pady=6, command=lambda dr=d: move(dr)).pack(side="left", padx=4)

spawn()
spawn()
render()
root.mainloop()
