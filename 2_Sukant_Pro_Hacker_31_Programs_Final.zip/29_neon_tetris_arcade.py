# 29. Full Playable Neon Tetris Arcade (Arrow Keys OR On-Screen Touch Buttons!)
import tkinter as tk
import random

root = tk.Tk()
root.title("NEON TETRIS // ARROWS OR TOUCH CONTROLS")
root.configure(bg="#06080f")

COLS, ROWS, CELL = 10, 20, 24
SHAPES = [
    ([[1, 1, 1, 1]], "#00e5ff"),
    ([[1, 1], [1, 1]], "#ffd600"),
    ([[0, 1, 0], [1, 1, 1]], "#d500f9"),
    ([[1, 0, 0], [1, 1, 1]], "#2979ff"),
    ([[0, 0, 1], [1, 1, 1]], "#ff9100"),
    ([[0, 1, 1], [1, 1, 0]], "#00ff88"),
    ([[1, 1, 0], [0, 1, 1]], "#ff1744")
]

board = [[None] * COLS for _ in range(ROWS)]
score = [0]
cur = {"shape": None, "col": "", "x": 3, "y": 0}
game_over = [False]

lbl = tk.Label(root, text="SCORE: 0", fg="#00ff88", bg="#06080f", font=("Consolas", 14, "bold"))
lbl.pack(pady=4)

cv = tk.Canvas(root, width=COLS * CELL, height=ROWS * CELL, bg="#0a0e18", highlightthickness=1, highlightbackground="#00e5ff")
cv.pack()

def valid(shape, x, y):
    for r, row in enumerate(shape):
        for c, val in enumerate(row):
            if val:
                nx, ny = x + c, y + r
                if nx < 0 or nx >= COLS or ny >= ROWS or (ny >= 0 and board[ny][nx]):
                    return False
    return True

def spawn():
    s, col = random.choice(SHAPES)
    cur["shape"], cur["col"], cur["x"], cur["y"] = [r[:] for r in s], col, COLS // 2 - len(s[0]) // 2, 0
    if not valid(cur["shape"], cur["x"], cur["y"]):
        game_over[0] = True

def lock():
    for r, row in enumerate(cur["shape"]):
        for c, val in enumerate(row):
            if val and cur["y"] + r >= 0:
                board[cur["y"] + r][cur["x"] + c] = cur["col"]
    new_board = [row for row in board if any(cell is None for cell in row)]
    cleared = ROWS - len(new_board)
    if cleared:
        score[0] += cleared * 100
        lbl.config(text=f"SCORE: {score[0]}")
        for _ in range(cleared):
            new_board.insert(0, [None] * COLS)
        board[:] = new_board
    spawn()

def draw():
    cv.delete("all")
    for r in range(ROWS):
        for c in range(COLS):
            if board[r][c]:
                cv.create_rectangle(c * CELL + 1, r * CELL + 1, (c + 1) * CELL - 1, (r + 1) * CELL - 1, fill=board[r][c], outline="")
    if not game_over[0] and cur["shape"]:
        for r, row in enumerate(cur["shape"]):
            for c, val in enumerate(row):
                if val:
                    x, y = cur["x"] + c, cur["y"] + r
                    cv.create_rectangle(x * CELL + 1, y * CELL + 1, (x + 1) * CELL - 1, (y + 1) * CELL - 1, fill=cur["col"], outline="#fff")
    else:
        cv.create_text(COLS * CELL // 2, ROWS * CELL // 2, text="GAME OVER", fill="#ff1744", font=("Consolas", 22, "bold"))

def move_piece(dx, dy):
    if not game_over[0] and valid(cur["shape"], cur["x"] + dx, cur["y"] + dy):
        cur["x"] += dx
        cur["y"] += dy
        draw()
        return True
    return False

def rotate():
    if game_over[0]: return
    rot = [list(row) for row in zip(*cur["shape"][::-1])]
    if valid(rot, cur["x"], cur["y"]):
        cur["shape"] = rot
        draw()

def tick():
    if not game_over[0]:
        if not move_piece(0, 1):
            lock()
            draw()
        root.after(340, tick)

root.bind("<Left>", lambda e: move_piece(-1, 0))
root.bind("<Right>", lambda e: move_piece(1, 0))
root.bind("<Down>", lambda e: move_piece(0, 1))
root.bind("<Up>", lambda e: rotate())

ctrl = tk.Frame(root, bg="#06080f")
ctrl.pack(pady=6)
tk.Button(ctrl, text="◀", bg="#112233", fg="#00e5ff", font=("Consolas", 12, "bold"), width=4, command=lambda: move_piece(-1, 0)).pack(side="left", padx=3)
tk.Button(ctrl, text="⟳", bg="#221133", fg="#d500f9", font=("Consolas", 12, "bold"), width=4, command=rotate).pack(side="left", padx=3)
tk.Button(ctrl, text="▼", bg="#112233", fg="#00ff88", font=("Consolas", 12, "bold"), width=4, command=lambda: move_piece(0, 1)).pack(side="left", padx=3)
tk.Button(ctrl, text="▶", bg="#112233", fg="#00e5ff", font=("Consolas", 12, "bold"), width=4, command=lambda: move_piece(1, 0)).pack(side="left", padx=3)

spawn()
draw()
tick()
root.mainloop()
