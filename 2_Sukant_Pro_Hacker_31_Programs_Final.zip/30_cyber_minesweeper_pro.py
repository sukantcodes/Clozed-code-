# 30. Hacker-Themed Cyber Minesweeper Pro (Touch Flag-Toggle + Flood-Fill Reveal!)
import tkinter as tk
import random

root = tk.Tk()
root.title("CYBER MINESWEEPER // DEFUSE THE MALWARE NODES!")
root.configure(bg="#060a10")

SIZE, MINES = 10, 14
flag_mode = [False]
game_over = [False]
mines = set()
revealed = set()
flagged = set()

top = tk.Frame(root, bg="#060a10")
top.pack(pady=6)
status = tk.Label(top, text=f"MALWARE NODES: {MINES}", fg="#00ff88", bg="#060a10", font=("Consolas", 12, "bold"))
status.pack(side="left", padx=10)

mode_btn = tk.Button(top, text="MODE: SCAN", bg="#0d2b1d", fg="#00ff88", font=("Consolas", 10, "bold"),
                     command=lambda: toggle_mode())
mode_btn.pack(side="left", padx=6)

def toggle_mode():
    flag_mode[0] = not flag_mode[0]
    mode_btn.config(text="MODE: FLAG ⚑" if flag_mode[0] else "MODE: SCAN",
                    fg="#ffd600" if flag_mode[0] else "#00ff88")

grid_f = tk.Frame(root, bg="#060a10")
grid_f.pack(padx=10, pady=6)
btns = [[None] * SIZE for _ in range(SIZE)]

def count_adj(r, c):
    return sum((r + dr, c + dc) in mines for dr in (-1, 0, 1) for dc in (-1, 0, 1))

def reveal(r, c):
    if (r, c) in revealed or (r, c) in flagged:
        return
    revealed.add((r, c))
    if (r, c) in mines:
        game_over[0] = True
        for mr, mc in mines:
            btns[mr][mc].config(text="✖", bg="#b71c1c", fg="#fff")
        status.config(text="BREACH DETECTED! GAME OVER", fg="#ff1744")
        return
    n = count_adj(r, c)
    cols = {1: "#00e5ff", 2: "#00ff88", 3: "#ffd600", 4: "#ff4081"}
    btns[r][c].config(text=str(n) if n else "", bg="#0b131f", fg=cols.get(n, "#ff1744"), relief="sunken")
    if n == 0:
        for dr in (-1, 0, 1):
            for dc in (-1, 0, 1):
                nr, nc = r + dr, c + dc
                if 0 <= nr < SIZE and 0 <= nc < SIZE:
                    reveal(nr, nc)
    if len(revealed) == SIZE * SIZE - MINES:
        game_over[0] = True
        status.config(text="ALL MALWARE DEFUSED! YOU WIN!", fg="#00e5ff")

def on_click(r, c):
    if game_over[0]:
        return
    if flag_mode[0]:
        if (r, c) not in revealed:
            if (r, c) in flagged:
                flagged.remove((r, c))
                btns[r][c].config(text="", fg="#fff")
            else:
                flagged.add((r, c))
                btns[r][c].config(text="⚑", fg="#ffd600")
    else:
        reveal(r, c)

def new_game():
    game_over[0] = False
    revealed.clear()
    flagged.clear()
    mines.clear()
    mines.update(random.sample([(r, c) for r in range(SIZE) for c in range(SIZE)], MINES))
    status.config(text=f"MALWARE NODES: {MINES}", fg="#00ff88")
    for r in range(SIZE):
        for c in range(SIZE):
            btns[r][c].config(text="", bg="#162233", fg="#fff", relief="raised")

for r in range(SIZE):
    for c in range(SIZE):
        b = tk.Button(grid_f, text="", width=3, height=1, font=("Consolas", 12, "bold"),
                      bg="#162233", fg="#fff", command=lambda rr=r, cc=c: on_click(rr, cc))
        b.grid(row=r, column=c, padx=1, pady=1)
        btns[r][c] = b

tk.Button(top, text="NEW SCAN", bg="#0d1f33", fg="#00e5ff", font=("Consolas", 10, "bold"),
          command=new_game).pack(side="left", padx=6)

new_game()
root.mainloop()
