# 31. Realistic 4K Paper Scenery — Artist Sketch, Watercolor Colorization & Living Scene
# Pure Python Standard Library (tkinter, math, random) — Works everywhere, ZERO pip installs!
#
# Features:
#   - True 4K (3840x2160) vector space that dynamically auto-fits ANY screen size & aspect ratio
#   - Draws smoothly like an artist sketching on cream cotton paper with an animated graphite pencil
#   - Includes: Snow-capped Alpine Mountains, Sunlit Clouds, Soaring Birds, 3D Village Houses with
#     Picket Fences & Chimneys, a Curving 3D-Perspective Railway Line emerging from a Stone Tunnel
#     with Sleepers & Telegraph Poles, and Realistic Trees with 500+ individual veined leaves!
#   - Layered realistic watercolor shading & shadows, followed by a living scenic train & birds
#   - Automatically signs off at the end: "Programmed Drawing By Sukant"
#
# Controls:
#   Mouse Wheel / Buttons : Zoom up to 10x (inspect a single leaf, window, or rail!)
#   Click + Drag          : Pan anywhere on the 4K artwork
#   F11 / Esc             : Toggle Fullscreen

import tkinter as tk
import math
import random

VW, VH = 3840.0, 2160.0
SIGNATURE_TEXT = "Programmed Drawing By Sukant"

root = tk.Tk()
root.title("4K Realistic Scenery // Programmed Drawing By Sukant")
root.configure(bg="#191b20")

# Auto-fit initial window cleanly on any display (laptop, desktop, 4:3 lab monitor, tablet)
sw = root.winfo_screenwidth()
sh = root.winfo_screenheight()
init_w = max(640, min(int(sw * 0.92), 1600))
init_h = max(420, min(int(sh * 0.86), 960))
root.geometry(f"{init_w}x{init_h}")
root.minsize(520, 340)

# ---------------- TOP CONTROL BAR ----------------
hud = tk.Frame(root, bg="#14161b", height=38)
hud.pack(fill="x", side="top")

phase_lbl = tk.Label(
    hud,
    text="STEP 1/3: PENCIL SKETCHING ON PAPER...",
    fg="#f3d082", bg="#14161b", font=("Consolas", 10, "bold")
)
phase_lbl.pack(side="left", padx=10, pady=6)

prog_lbl = tk.Label(
    hud,
    text="0.0% | 4K (3840x2160)",
    fg="#8be0a4", bg="#14161b", font=("Consolas", 10, "bold")
)
prog_lbl.pack(side="left", padx=8)

cv = tk.Canvas(root, bg="#191b20", highlightthickness=0)
cv.pack(fill="both", expand=True)

# ---------------- CAMERA & STATE ----------------
cam = {
    "fit_scale": 1.0,
    "fit_ox": 0.0,
    "fit_oy": 0.0,
    "user_zoom": 1.0,
    "pan_x": 0.0,
    "pan_y": 0.0,
    "scale": 1.0,
    "ox": 0.0,
    "oy": 0.0,
    "vw_px": init_w,
    "vh_px": max(200, init_h - 38),
}

# Realistic artist speed presets: (Label, sketch_ops_per_tick, color_ops_per_tick, delay_ms)
SPEED_PRESETS = [
    ("NATURAL", 2, 3, 14),
    ("SLOW",    1, 1, 22),
    ("FAST",    6, 9, 12),
    ("TURBO",  24, 36, 8),
]
speed_idx = [0]
paused = [False]

state = {
    "phase": "SKETCH",     # SKETCH -> COLORIZE -> SIGNATURE -> LIVE
    "sketch_idx": 0,
    "color_idx": 0,
    "sig_idx": 0,
    "sketch_ops": [],
    "color_ops": [],
    "rail_curve": [],
    "pencil_ids": [],
    "sig_ids": [],
    "live": {"birds": [], "smoke": [], "leaves": [], "train_t": -0.05, "train_ids": [], "train_smoke": []},
    "fullscreen": False,
}


def recompute_transform():
    """Fits the full 4K (3840x2160) paper cleanly inside ANY window or monitor size."""
    w = max(120, cam["vw_px"])
    h = max(120, cam["vh_px"])
    pad = 10
    fs = min((w - pad * 2) / VW, (h - pad * 2) / VH)
    fox = (w - VW * fs) * 0.5
    foy = (h - VH * fs) * 0.5
    cam["fit_scale"] = fs
    cam["fit_ox"] = fox
    cam["fit_oy"] = foy

    cx, cy = w * 0.5, h * 0.5
    z = cam["user_zoom"]
    cam["scale"] = fs * z
    cam["ox"] = cx - (cx - fox) * z + cam["pan_x"]
    cam["oy"] = cy - (cy - foy) * z + cam["pan_y"]


def to_scr(x, y):
    return x * cam["scale"] + cam["ox"], y * cam["scale"] + cam["oy"]


def to_scr_pts(pts):
    sc, ox, oy = cam["scale"], cam["ox"], cam["oy"]
    out = []
    for i in range(0, len(pts), 2):
        out.append(pts[i] * sc + ox)
        out.append(pts[i + 1] * sc + oy)
    return out


def lerp_hex(c1, c2, t):
    t = max(0.0, min(1.0, t))
    r1, g1, b1 = int(c1[1:3], 16), int(c1[3:5], 16), int(c1[5:7], 16)
    r2, g2, b2 = int(c2[1:3], 16), int(c2[3:5], 16), int(c2[5:7], 16)
    return f"#{int(r1 + (r2 - r1) * t):02x}{int(g1 + (g2 - g1) * t):02x}{int(b1 + (b2 - b1) * t):02x}"


def multi_grad(stops, t):
    t = max(0.0, min(1.0, t))
    s = t * (len(stops) - 1)
    i = min(int(s), len(stops) - 2)
    return lerp_hex(stops[i], stops[i + 1], s - i)


def cubic_bezier(p0, p1, p2, p3, t):
    u = 1.0 - t
    x = u**3 * p0[0] + 3 * u**2 * t * p1[0] + 3 * u * t**2 * p2[0] + t**3 * p3[0]
    y = u**3 * p0[1] + 3 * u**2 * t * p1[1] + 3 * u * t**2 * p2[1] + t**3 * p3[1]
    return x, y


def make_leaf_geometry(cx, cy, length, width, angle):
    """Natural 8-point pointed botanical leaf + midrib vein + lateral veins."""
    ca, sa = math.cos(angle), math.sin(angle)

    def rot(lx, ly):
        return cx + lx * ca - ly * sa, cy + lx * sa + ly * ca

    shape = [
        (0.0, 0.0),
        (length * 0.22, -width * 0.42),
        (length * 0.52, -width * 0.50),
        (length * 0.80, -width * 0.26),
        (length, 0.0),
        (length * 0.80, width * 0.26),
        (length * 0.52, width * 0.50),
        (length * 0.22, width * 0.42),
    ]
    pts = []
    for lx, ly in shape:
        px, py = rot(lx, ly)
        pts.extend([px, py])

    m0, m1 = rot(length * 0.05, 0.0), rot(length * 0.90, 0.0)
    v1a, v1b = rot(length * 0.34, 0.0), rot(length * 0.58, -width * 0.34)
    v2a, v2b = rot(length * 0.34, 0.0), rot(length * 0.58, width * 0.34)
    return pts, [m0[0], m0[1], m1[0], m1[1]], [v1a[0], v1a[1], v1b[0], v1b[1]], [v2a[0], v2a[1], v2b[0], v2b[1]]


def fractal_ridge(x0, x1, y_base, amp, rough, iters, rng):
    pts = [(x0, y_base), ((x0 + x1) * 0.5, y_base - amp), (x1, y_base)]
    cur_amp = amp * 0.50
    for _ in range(iters):
        nxt = [pts[0]]
        for i in range(len(pts) - 1):
            ax, ay = pts[i]
            bx, by = pts[i + 1]
            mx = (ax + bx) * 0.5
            my = (ay + by) * 0.5 + rng.uniform(-cur_amp, cur_amp)
            nxt.append((mx, my))
            nxt.append((bx, by))
        pts = nxt
        cur_amp *= rough
    return pts


def build_realistic_blueprint():
    """
    Creates a realistic golden-morning countryside drawing on cream paper with strict back-to-front layering:
      L_SUN -> L_CLOUD -> L_MTN1 -> L_MTN2 -> L_HILL_FAR -> L_THILL -> L_HILL_MID ->
      L_PINE -> L_HOUSE -> L_HILL_FG -> L_RAIL -> L_TREE -> L_FG -> L_BIRD
    """
    rng = random.Random(2026)
    sketch = []  # (kind, coords, kwargs, tag, layer_tag)
    color = []

    p_light = "#8f949c"   # 2H pencil (distant mountains, clouds)
    p_mid   = "#555a61"   # HB pencil (mid hills, houses, railway)
    p_dark  = "#26292e"   # 2B pencil (foreground trees, crisp details)

    horizon_y = 1245.0
    sun_x, sun_y, sun_r = 2520.0, 520.0, 118.0

    # ==================================================================
    # 1. SKY WASH & MORNING SUN & CLOUDS
    # ==================================================================
    sky_stops = ["#4f81bd", "#72a0d1", "#9ec0e0", "#cbdae6", "#eee2cf", "#fce8c7"]
    sky_bands = 46
    bh = (horizon_y + 80) / sky_bands
    for i in range(sky_bands):
        y1 = i * bh
        y2 = y1 + bh + 2.5
        color.append(("insert_below", "L_SUN", "rect", [0, y1, VW, y2],
                      {"fill": multi_grad(sky_stops, i / (sky_bands - 1)), "outline": ""}, "sky_bg"))

    sketch.append(("oval", [sun_x - sun_r, sun_y - sun_r, sun_x + sun_r, sun_y + sun_r],
                   {"outline": p_light, "width": 1.4}, "sun_disc", "L_SUN"))
    for hi in range(10, 0, -1):
        hr = sun_r + hi * 38
        hcol = lerp_hex("#f7dfc2", "#fffbe6", 1.0 - hi / 11.0)
        color.append(("insert_below", "L_SUN", "oval", [sun_x - hr, sun_y - hr, sun_x + hr, sun_y + hr],
                      {"fill": "", "outline": hcol, "width": 2.4}, "sky_sun"))
    color.append(("recolor", "sun_disc", {"fill": "#fffbe0", "outline": "#ffe9a8"}))

    # Soft Fluffy Clouds
    clouds = [
        (540, 310, 310, 9), (1460, 250, 360, 10), (2180, 340, 260, 8),
        (3140, 290, 330, 9), (980, 490, 240, 7)
    ]
    for ci, (cx, cy, cw, npuffs) in enumerate(clouds):
        for pi in range(npuffs):
            t = pi / max(1, npuffs - 1)
            px = cx + (t - 0.5) * cw * 1.35 + rng.uniform(-18, 18)
            arch = math.sin(t * math.pi)
            py = cy - arch * cw * 0.16 + rng.uniform(-10, 12)
            rx = cw * rng.uniform(0.15, 0.25) * (0.65 + 0.50 * arch)
            ry = rx * rng.uniform(0.45, 0.62)
            stag = f"cl_s_{ci}_{pi}"
            sketch.append(("oval", [px - rx, py - ry + 10, px + rx, py + ry + 15],
                           {"outline": p_light, "width": 0.9}, stag, "L_CLOUD"))
            color.append(("recolor", stag, {"fill": "#c9d4e3", "outline": ""}))
            btag = f"cl_b_{ci}_{pi}"
            sketch.append(("oval", [px - rx * 0.92, py - ry, px + rx * 0.92, py + ry * 0.88],
                           {"outline": p_light, "width": 1.0}, btag, "L_CLOUD"))
            color.append(("recolor", btag, {"fill": "#fffcf5", "outline": "#eef2f7"}))

    # ==================================================================
    # 2. LAYERED SNOW-CAPPED MOUNTAINS (True Back-to-Front Layering!)
    # ==================================================================
    def build_mountain(prefix, layer_tag, peaks, y_base, body_col, shd_col, lit_col, snow=True, pencil=p_light):
        ridge = []
        for x0, x1, amp in peaks:
            seg = fractal_ridge(x0, x1, y_base, amp, 0.52, 5, rng)
            if ridge:
                seg = seg[1:]
            ridge.extend(seg)

        # Sketch smooth continuous ridge strokes left to right
        for i in range(0, len(ridge) - 1, 2):
            sub = ridge[i:i + 3]
            cpts = []
            for x, y in sub:
                cpts.extend([x, y])
            sketch.append(("line", cpts, {"fill": pencil, "width": 1.7}, f"{prefix}_r_{i}", layer_tag))

        # Mountain body fill inserted strictly below its own sketch lines (hides everything behind it!)
        body = [0, horizon_y + 200]
        for x, y in ridge:
            body.extend([x, y])
        body.extend([VW, horizon_y + 200])
        color.append(("insert_below", layer_tag, "poly", body, {"fill": body_col, "outline": ""}, f"{prefix}_body"))

        # 3D Ridge Facets (Shadow Left / Sunlit Right)
        for i in range(3, len(ridge) - 3):
            px, py = ridge[i]
            if py < ridge[i - 1][1] and py < ridge[i + 1][1] and py < y_base - 110:
                drop = min(y_base - py + 80, rng.uniform(180, 390))
                sx = px - rng.uniform(10, 48)
                sy = py + drop
                lx = px - drop * rng.uniform(0.70, 1.05)
                rx = px + drop * rng.uniform(0.75, 1.15)
                sketch.append(("line", [px, py, sx, sy], {"fill": pencil, "width": 1.1}, f"{prefix}_sp_{i}", layer_tag))
                color.append(("insert_below", layer_tag, "poly", [px, py, lx, sy, sx, sy],
                              {"fill": shd_col, "outline": ""}, f"{prefix}_det"))
                color.append(("insert_below", layer_tag, "poly", [px, py, sx, sy, rx, sy],
                              {"fill": lit_col, "outline": ""}, f"{prefix}_det"))
                if snow and py < 900:
                    sh = drop * 0.44
                    s_shd = [px, py, px - sh * 0.72, py + sh * 0.88, px - sh * 0.08, py + sh]
                    s_lit = [px, py, px - sh * 0.08, py + sh, px + sh * 0.78, py + sh * 0.90]
                    color.append(("insert_below", layer_tag, "poly", s_shd, {"fill": "#c8d6e8", "outline": ""}, f"{prefix}_det"))
                    color.append(("insert_below", layer_tag, "poly", s_lit, {"fill": "#fffbf2", "outline": ""}, f"{prefix}_det"))

    build_mountain("mtn1", "L_MTN1", [(0, 960, 510), (960, 1920, 620), (1920, 2940, 540), (2940, VW, 470)],
                   1180, "#7c8fae", "#617596", "#9eb0c9", snow=True, pencil=p_light)
    build_mountain("mtn2", "L_MTN2", [(0, 1300, 320), (1300, 2550, 260), (2550, VW, 360)],
                   1250, "#506e75", "#3c565e", "#6f8f8c", snow=False, pencil=p_mid)

    # ==================================================================
    # 3. ROLLING SUNLIT GREEN MEADOW HILLS
    # ==================================================================
    def add_hill(tag, layer_tag, pts_xy, fill_col, edge_col, pencil=p_mid):
        for i in range(0, len(pts_xy) - 1, 2):
            seg = pts_xy[i:i + 3]
            c = []
            for x, y in seg:
                c.extend([x, y])
            sketch.append(("line", c, {"fill": pencil, "width": 1.6}, f"{tag}_c_{i}", layer_tag))
        poly = [0, VH]
        for x, y in pts_xy:
            poly.extend([x, y])
        poly.extend([VW, VH])
        color.append(("insert_below", layer_tag, "poly", poly, {"fill": fill_col, "outline": edge_col}, tag))

    far_hill = [(x, 1255 + 42 * math.sin(x * 0.0017 + 0.5) - 18 * math.cos(x * 0.0038)) for x in range(0, int(VW) + 1, 120)]
    add_hill("hill_far", "L_HILL_FAR", far_hill, "#7da362", "#6c9153", p_mid)

    # Right hillside rising cleanly around the railway tunnel
    tunnel_hill = [
        (2360, 1390), (2620, 1255), (2920, 1155), (3260, 1115),
        (3580, 1145), (VW, 1200), (VW, 1560), (2360, 1560)
    ]
    sketch.append(("poly", [v for pt in tunnel_hill for v in pt], {"fill": "", "outline": p_mid, "width": 1.6}, "t_hill", "L_THILL"))
    color.append(("recolor", "t_hill", {"fill": "#537a47", "outline": "#426338"}))

    # Mid valley meadow (stays cleanly below tunnel mouth at x=2920, y=1340!)
    mid_meadow = [(x, 1410 + 36 * math.sin(x * 0.0015 - 0.5)) for x in range(0, int(VW) + 1, 120)]
    add_hill("hill_mid", "L_HILL_MID", mid_meadow, "#618c4d", "#517840", p_mid)

    # ==================================================================
    # 4. HILLSIDE PINES & 3 REALISTIC 3D VILLAGE HOUSES
    # ==================================================================
    def add_pine(pid, cx, by, h):
        tw = h * 0.08
        sketch.append(("rect", [cx - tw, by - h * 0.22, cx + tw, by], {"fill": "", "outline": p_mid, "width": 1.0}, f"{pid}_tr", "L_PINE"))
        color.append(("recolor", f"{pid}_tr", {"fill": "#4d3627", "outline": ""}))
        for k in range(4):
            ty = by - h * (0.18 + k * 0.21)
            bw = h * (0.34 - k * 0.065)
            bh_t = h * 0.32
            lit = [cx, ty - bh_t, cx, ty + 10, cx + bw, ty + 8]
            sketch.append(("poly", [cx, ty - bh_t, cx - bw, ty + 8, cx + bw, ty + 8],
                           {"fill": "", "outline": p_mid, "width": 1.0}, f"{pid}_b_{k}", "L_PINE"))
            color.append(("recolor", f"{pid}_b_{k}", {"fill": "#284a31", "outline": "#1d3824"}))
            color.append(("insert_above", f"{pid}_b_{k}", "poly", lit, {"fill": "#3d6b43", "outline": ""}, f"{pid}_lit"))

    pine_spots = [
        (780, 1385, 130), (855, 1375, 155), (930, 1390, 120), (1390, 1395, 145),
        (1475, 1385, 165), (1560, 1405, 125), (2180, 1370, 135), (2260, 1360, 155),
        (2680, 1215, 145), (2770, 1195, 165), (3320, 1155, 155), (3420, 1170, 135)
    ]
    for idx, (px, py, ph) in enumerate(pine_spots):
        add_pine(f"pine_{idx}", px, py, ph)

    def add_3d_house(hid, x, y, w, h, roof_col, wall_front, wall_side):
        side_w = w * 0.44
        roof_h = h * 0.62

        # Soft ground shadow
        sh_pts = [x - side_w * 0.55, y + h, x + w + side_w * 0.9, y + h,
                  x + w + side_w * 0.5, y + h + 28, x - side_w * 0.85, y + h + 24]
        color.append(("insert_below", f"{hid}_fw", "poly", sh_pts, {"fill": "#35572c", "outline": ""}, f"{hid}_shd"))

        # Chimney
        ch_x = x + w * 0.72
        sketch.append(("rect", [ch_x, y - roof_h * 0.88, ch_x + w * 0.14, y - roof_h * 0.12],
                       {"fill": "", "outline": p_mid, "width": 1.3}, f"{hid}_ch", "L_HOUSE"))
        color.append(("recolor", f"{hid}_ch", {"fill": "#7d6b61", "outline": "#4a3e38"}))

        # Front sunlit wall
        sketch.append(("rect", [x, y, x + w, y + h], {"fill": "", "outline": p_dark, "width": 1.6}, f"{hid}_fw", "L_HOUSE"))
        color.append(("recolor", f"{hid}_fw", {"fill": wall_front, "outline": "#706252"}))

        # Shaded 3D side wall
        sw_pts = [x + w, y, x + w + side_w, y - 16, x + w + side_w, y + h - 14, x + w, y + h]
        sketch.append(("poly", sw_pts, {"fill": "", "outline": p_dark, "width": 1.6}, f"{hid}_sw", "L_HOUSE"))
        color.append(("recolor", f"{hid}_sw", {"fill": wall_side, "outline": "#5e5245"}))

        # Front Gable
        gable = [x, y, x + w * 0.5, y - roof_h, x + w, y]
        sketch.append(("poly", gable, {"fill": "", "outline": p_dark, "width": 1.5}, f"{hid}_gb", "L_HOUSE"))
        color.append(("recolor", f"{hid}_gb", {"fill": wall_front, "outline": "#706252"}))

        # 3D Sloped Roof Plane
        roof_side = [x + w * 0.5, y - roof_h, x + w * 0.5 + side_w, y - roof_h - 14,
                     x + w + side_w + 14, y - 12, x + w + 14, y + 6]
        sketch.append(("poly", roof_side, {"fill": "", "outline": p_dark, "width": 1.8}, f"{hid}_rs", "L_HOUSE"))
        color.append(("recolor", f"{hid}_rs", {"fill": roof_col, "outline": "#422219"}))

        for rrow in range(1, 5):
            f = rrow / 5.0
            rx1 = (x + w * 0.5) + (w * 0.5 + 14) * f
            ry1 = (y - roof_h) + (roof_h + 6) * f
            rx2 = (x + w * 0.5 + side_w) + (w * 0.5 + 14) * f
            ry2 = (y - roof_h - 14) + (roof_h + 2) * f
            sketch.append(("line", [rx1, ry1, rx2, ry2], {"fill": p_mid, "width": 0.9}, f"{hid}_rt_{rrow}", "L_HOUSE"))
            color.append(("recolor", f"{hid}_rt_{rrow}", {"fill": lerp_hex(roof_col, "#29120c", 0.35)}))

        sketch.append(("line", [x - 16, y + 6, x + w * 0.5, y - roof_h - 4, x + w + 16, y + 6],
                       {"fill": p_dark, "width": 2.6}, f"{hid}_eave", "L_HOUSE"))
        color.append(("recolor", f"{hid}_eave", {"fill": "#4d2b1f"}))

        # Wooden Front Door
        dw, dh = w * 0.24, h * 0.54
        dx = x + w * 0.38
        sketch.append(("rect", [dx, y + h - dh, dx + dw, y + h], {"fill": "", "outline": p_dark, "width": 1.4}, f"{hid}_dr", "L_HOUSE"))
        color.append(("recolor", f"{hid}_dr", {"fill": "#6e4228", "outline": "#381f11"}))

        # Paned Windows
        for wi, wx in enumerate([x + w * 0.10, x + w * 0.68]):
            ww, wh = w * 0.21, h * 0.30
            wy = y + h * 0.26
            wtag = f"{hid}_w_{wi}"
            sketch.append(("rect", [wx, wy, wx + ww, wy + wh], {"fill": "", "outline": p_dark, "width": 1.3}, wtag, "L_HOUSE"))
            color.append(("recolor", wtag, {"fill": "#8bb8d6", "outline": "#3d2a1e"}))
            sketch.append(("line", [wx + ww * 0.5, wy, wx + ww * 0.5, wy + wh], {"fill": p_mid, "width": 1.0}, f"{wtag}_v", "L_HOUSE"))
            sketch.append(("line", [wx, wy + wh * 0.5, wx + ww, wy + wh * 0.5], {"fill": p_mid, "width": 1.0}, f"{wtag}_h", "L_HOUSE"))

        swx = x + w + side_w * 0.32
        swy = y + h * 0.26
        sketch.append(("poly", [swx, swy, swx + side_w * 0.36, swy - 5, swx + side_w * 0.36, swy + h * 0.28 - 5, swx, swy + h * 0.28],
                       {"fill": "", "outline": p_dark, "width": 1.2}, f"{hid}_swin", "L_HOUSE"))
        color.append(("recolor", f"{hid}_swin", {"fill": "#6d98b5", "outline": "#36251a"}))

    add_3d_house("h1", 960,  1435, 250, 155, "#b34d39", "#f4ead8", "#cfc1aa")
    add_3d_house("h2", 1540, 1385, 190, 122, "#516478", "#efe5d5", "#c7baa5")
    add_3d_house("h3", 1915, 1365, 145,  96, "#a85c38", "#f2e6d0", "#c9bca5")

    # Wooden Picket Fence + Garden Path
    sketch.append(("line", [900, 1612, 1345, 1612], {"fill": p_mid, "width": 1.2}, "fence_r1", "L_HOUSE"))
    sketch.append(("line", [900, 1632, 1345, 1632], {"fill": p_mid, "width": 1.2}, "fence_r2", "L_HOUSE"))
    color.append(("recolor", "fence_r1", {"fill": "#7a5c45"}))
    color.append(("recolor", "fence_r2", {"fill": "#7a5c45"}))
    for fx in range(905, 1348, 22):
        ftag = f"fp_{fx}"
        sketch.append(("line", [fx, 1596, fx, 1645], {"fill": p_mid, "width": 1.6}, ftag, "L_HOUSE"))
        color.append(("recolor", ftag, {"fill": "#967458"}))

    path_pts = [1055, 1590, 1085, 1590, 1145, 1655, 1255, 1720, 1165, 1735, 1085, 1665]
    sketch.append(("poly", path_pts, {"fill": "", "outline": p_mid, "width": 1.1}, "cottage_path", "L_HOUSE"))
    color.append(("recolor", "cottage_path", {"fill": "#bfa784", "outline": "#9c8565"}))

    # ==================================================================
    # 5. FOREGROUND MEADOW BANK
    # ==================================================================
    fg_meadow = [(x, 1715 + 42 * math.sin(x * 0.0018 + 1.2)) for x in range(0, int(VW) + 1, 120)]
    add_hill("hill_fg", "L_HILL_FG", fg_meadow, "#436e38", "#35592b", p_dark)

    # ==================================================================
    # 6. 3D PERSPECTIVE RAILWAY LINE + STONE TUNNEL + POLES
    # ==================================================================
    rp0 = (2920.0, 1340.0)
    rp1 = (2420.0, 1430.0)
    rp2 = (2680.0, 1755.0)
    rp3 = (1760.0, 2190.0)

    N_RAIL = 72
    rail_samples = []
    for i in range(N_RAIL + 1):
        t = i / N_RAIL
        x, y = cubic_bezier(rp0, rp1, rp2, rp3, t)
        x2, y2 = cubic_bezier(rp0, rp1, rp2, rp3, min(1.0, t + 0.005))
        tx, ty = x2 - x, y2 - y
        mag = max(1e-5, math.hypot(tx, ty))
        nx, ny = -ty / mag, tx / mag
        persp = 0.22 + (t ** 1.65) * 2.45
        half_gauge = 36.0 * persp
        rail_samples.append((t, x, y, nx, ny, persp, half_gauge))

    # Stone Railway Tunnel Portal
    tx0, ty0 = rp0[0] + 12, rp0[1]
    tunnel_arch = [
        tx0 - 65, ty0 + 18, tx0 - 65, ty0 - 48, tx0 - 42, ty0 - 82,
        tx0, ty0 - 94, tx0 + 42, ty0 - 82, tx0 + 65, ty0 - 48, tx0 + 65, ty0 + 18
    ]
    tunnel_hole = [
        tx0 - 42, ty0 + 18, tx0 - 42, ty0 - 42, tx0 - 25, ty0 - 66,
        tx0, ty0 - 74, tx0 + 25, ty0 - 66, tx0 + 42, ty0 - 42, tx0 + 42, ty0 + 18
    ]
    sketch.append(("poly", tunnel_arch, {"fill": "", "outline": p_dark, "width": 1.8}, "tun_stone", "L_RAIL"))
    color.append(("recolor", "tun_stone", {"fill": "#7d7972", "outline": "#423f3b"}))
    sketch.append(("poly", tunnel_hole, {"fill": "", "outline": p_dark, "width": 1.6}, "tun_dark", "L_RAIL"))
    color.append(("recolor", "tun_dark", {"fill": "#14161a", "outline": "#2e2d2b"}))

    # Gravel Ballast Embankment Bed
    left_bal, right_bal = [], []
    for t, x, y, nx, ny, persp, hg in rail_samples:
        bw = hg * 1.95
        left_bal.append((x - nx * bw, y - ny * bw))
        right_bal.append((x + nx * bw, y + ny * bw))
    bal_poly = [v for pt in left_bal for v in pt] + [v for pt in reversed(right_bal) for v in pt]
    sketch.append(("poly", bal_poly, {"fill": "", "outline": p_mid, "width": 1.3}, "rail_ballast", "L_RAIL"))
    color.append(("recolor", "rail_ballast", {"fill": "#8f8679", "outline": "#6b6358"}))

    # Wooden Railway Sleepers / Ties (Perspective-spaced!)
    t_pos = 0.02
    tie_idx = 0
    while t_pos < 0.99:
        fi = t_pos * N_RAIL
        i0 = min(N_RAIL - 1, int(fi))
        frac = fi - i0
        s0, s1 = rail_samples[i0], rail_samples[i0 + 1]
        x = s0[1] + (s1[1] - s0[1]) * frac
        y = s0[2] + (s1[2] - s0[2]) * frac
        nx = s0[3] + (s1[3] - s0[3]) * frac
        ny = s0[4] + (s1[4] - s0[4]) * frac
        persp = s0[5] + (s1[5] - s0[5]) * frac
        hg = s0[6] + (s1[6] - s0[6]) * frac

        tx, ty = ny, -nx
        tw = hg * 1.48
        th = 4.5 * persp
        p_a = (x - nx * tw - tx * th, y - ny * tw - ty * th)
        p_b = (x + nx * tw - tx * th, y + ny * tw - ty * th)
        p_c = (x + nx * tw + tx * th, y + ny * tw + ty * th)
        p_d = (x - nx * tw + tx * th, y - ny * tw + ty * th)
        ttag = f"tie_{tie_idx}"
        sketch.append(("poly", [p_a[0], p_a[1], p_b[0], p_b[1], p_c[0], p_c[1], p_d[0], p_d[1]],
                       {"fill": "", "outline": p_dark, "width": 1.1}, ttag, "L_RAIL"))
        color.append(("recolor", ttag, {"fill": lerp_hex("#695241", "#4a3325", t_pos), "outline": "#2b1c14"}))
        tie_idx += 1
        t_pos += 0.0085 + 0.026 * (t_pos ** 1.35)

    # Double Steel Rails + Bright Silver Highlight Line
    for side_idx, sign in enumerate((-1.0, 1.0)):
        for i in range(0, N_RAIL, 2):
            seg_pts = []
            for j in range(i, min(N_RAIL + 1, i + 3)):
                _, x, y, nx, ny, _, hg = rail_samples[j]
                seg_pts.extend([x + sign * nx * hg, y + sign * ny * hg])
            persp = rail_samples[i][5]
            rtag = f"rail_{side_idx}_{i}"
            w_rail = 1.6 + persp * 2.1
            sketch.append(("line", seg_pts, {"fill": p_dark, "width": w_rail}, rtag, "L_RAIL"))
            color.append(("recolor", rtag, {"fill": "#464f57"}))
            color.append(("insert_above", rtag, "line", seg_pts,
                          {"fill": "#dce6f0", "width": max(0.8, w_rail * 0.42)}, "r_shine"))

    # Perspective Telegraph Poles & Wires
    pole_ts = [0.10, 0.24, 0.42, 0.64, 0.88]
    pole_tops = []
    for pi, pt in enumerate(pole_ts):
        idx = min(N_RAIL, int(pt * N_RAIL))
        _, x, y, nx, ny, persp, hg = rail_samples[idx]
        bx = x - nx * (hg * 2.35)
        by = y - ny * (hg * 2.35)
        ph = 115.0 * persp
        cw = 22.0 * persp
        ptag, ctag = f"pole_{pi}", f"polec_{pi}"
        sketch.append(("line", [bx, by, bx, by - ph], {"fill": p_dark, "width": max(1.2, 2.2 * persp)}, ptag, "L_RAIL"))
        sketch.append(("line", [bx - cw, by - ph * 0.88, bx + cw, by - ph * 0.88],
                       {"fill": p_dark, "width": max(1.0, 1.6 * persp)}, ctag, "L_RAIL"))
        color.append(("recolor", ptag, {"fill": "#4a3728"}))
        color.append(("recolor", ctag, {"fill": "#3d2c1e"}))
        pole_tops.append((bx - cw * 0.7, by - ph * 0.88, bx + cw * 0.7, by - ph * 0.88))

    for pi in range(len(pole_tops) - 1):
        ax1, ay1, ax2, ay2 = pole_tops[pi]
        bx1, by1, bx2, by2 = pole_tops[pi + 1]
        for wi, (x1, y1, x2, y2) in enumerate([(ax1, ay1, bx1, by1), (ax2, ay2, bx2, by2)]):
            mx, my = (x1 + x2) * 0.5, (y1 + y2) * 0.5 + 18.0 + pi * 10.0
            wtag = f"wire_{pi}_{wi}"
            sketch.append(("line", [x1, y1, mx, my, x2, y2], {"fill": p_mid, "width": 0.9, "smooth": True}, wtag, "L_RAIL"))
            color.append(("recolor", wtag, {"fill": "#3c434a"}))

    # ==================================================================
    # 7. REALISTIC BRANCHING TREES WITH 500+ INDIVIDUAL VEINED LEAVES!
    # ==================================================================
    br_cnt = [0]
    lf_cnt = [0]

    def build_organic_tree(x, y, length, angle, thick, depth, palette, leaf_scale=1.0, leaf_density=1.0):
        if depth <= 0 or length < 16:
            return
        bend = rng.uniform(-0.14, 0.14)
        mx = x + (length * 0.52) * math.cos(angle + bend)
        my = y - (length * 0.52) * math.sin(angle + bend)
        x2 = x + length * math.cos(angle)
        y2 = y - length * math.sin(angle)

        perp = angle + math.pi * 0.5
        w1, wm, w2 = thick * 0.54, thick * 0.44, thick * 0.34
        bpts = [
            x + w1 * math.cos(perp), y - w1 * math.sin(perp),
            mx + wm * math.cos(perp), my - wm * math.sin(perp),
            x2 + w2 * math.cos(perp), y2 - w2 * math.sin(perp),
            x2 - w2 * math.cos(perp), y2 + w2 * math.sin(perp),
            mx - wm * math.cos(perp), my + wm * math.sin(perp),
            x - w1 * math.cos(perp), y + w1 * math.sin(perp),
        ]
        bid = f"tbr_{br_cnt[0]}"
        br_cnt[0] += 1
        sketch.append(("poly", bpts, {"fill": "", "outline": p_dark, "width": 1.15}, bid, "L_TREE"))
        bark_col = lerp_hex("#4d3525", "#6e4e38", max(0.0, min(1.0, (6 - depth) / 5.0)))
        color.append(("recolor", bid, {"fill": bark_col, "outline": "#2e1e14"}))

        if thick > 18:
            for off, bcol in [(-0.22, "#362317"), (0.22, "#876349")]:
                gpts = [
                    x + thick * off * math.cos(perp), y - thick * off * math.sin(perp),
                    mx + thick * off * 0.8 * math.cos(perp), my - thick * off * 0.8 * math.sin(perp),
                    x2 + thick * off * 0.6 * math.cos(perp), y2 - thick * off * 0.6 * math.sin(perp),
                ]
                gtag = f"tbk_{br_cnt[0]}_{off}"
                sketch.append(("line", gpts, {"fill": p_mid, "width": 1.0, "smooth": True}, gtag, "L_TREE"))
                color.append(("recolor", gtag, {"fill": bcol}))

        if depth <= 3:
            base_n = 6 if depth == 1 else (3 if depth == 2 else 2)
            n_leaves = max(1, int(round(base_n * leaf_density)))
            for _ in range(n_leaves):
                t = rng.uniform(0.30, 1.0)
                lx = x + (x2 - x) * t + rng.uniform(-22, 22) * leaf_scale
                ly = y + (y2 - y) * t + rng.uniform(-22, 22) * leaf_scale
                lang = -angle + rng.uniform(-1.45, 1.45)
                llen = rng.uniform(36, 62) * leaf_scale
                lwid = llen * rng.uniform(0.40, 0.54)
                lpts, midrib, lv1, lv2 = make_leaf_geometry(lx, ly, llen, lwid, lang)

                lid = f"lf_{lf_cnt[0]}"
                mid_id = f"lfm_{lf_cnt[0]}"
                lf_cnt[0] += 1

                sketch.append(("poly", lpts, {"fill": "", "outline": p_mid, "width": 0.9}, lid, "L_TREE"))
                sketch.append(("line", midrib, {"fill": p_light, "width": 0.65}, mid_id, "L_TREE"))

                sun_score = 0.50 + ((lx - 520) / 1400.0) * 0.25 + ((1350 - ly) / 900.0) * 0.25 + rng.uniform(-0.22, 0.24)
                l_fill = multi_grad(palette, sun_score)
                l_edge = lerp_hex(l_fill, "#152612", 0.38)
                v_col = lerp_hex(l_fill, "#f7f5c8", 0.45)
                color.append(("recolor", lid, {"fill": l_fill, "outline": l_edge}))
                color.append(("recolor", mid_id, {"fill": v_col}))

                if depth == 1 and leaf_scale >= 0.85:
                    v1_id, v2_id = f"lfv1_{lf_cnt[0]}", f"lfv2_{lf_cnt[0]}"
                    sketch.append(("line", lv1, {"fill": p_light, "width": 0.5}, v1_id, "L_TREE"))
                    sketch.append(("line", lv2, {"fill": p_light, "width": 0.5}, v2_id, "L_TREE"))
                    color.append(("recolor", v1_id, {"fill": v_col}))
                    color.append(("recolor", v2_id, {"fill": v_col}))

        if depth > 1:
            sp = rng.uniform(0.32, 0.50)
            build_organic_tree(x2, y2, length * rng.uniform(0.70, 0.80), angle + sp, thick * 0.66, depth - 1, palette, leaf_scale, leaf_density)
            build_organic_tree(x2, y2, length * rng.uniform(0.70, 0.80), angle - sp, thick * 0.66, depth - 1, palette, leaf_scale, leaf_density)
            if depth >= 4 and rng.random() < 0.65:
                build_organic_tree(x2, y2, length * rng.uniform(0.58, 0.70), angle + rng.uniform(-0.16, 0.16),
                                   thick * 0.55, depth - 1, palette, leaf_scale, leaf_density)

    # Dappled Ground Shadow under Left Hero Oak
    color.append(("insert_below", "L_TREE", "oval", [180, 1965, 860, 2065], {"fill": "#274721", "outline": ""}, "t_shd"))

    # 1) Left Foreground Hero Oak Tree
    oak_palette = ["#1d4220", "#2d612a", "#438033", "#64a13d", "#94bf4e", "#bfd66b"]
    build_organic_tree(520, 2015, 345, math.pi * 0.5 - 0.08, 86, 5, oak_palette, leaf_scale=1.08, leaf_density=1.15)

    # 2) Village Courtyard Shade Tree
    courtyard_pal = ["#234a26", "#376e33", "#52913e", "#7bb04d", "#a8cc66"]
    build_organic_tree(1375, 1620, 138, math.pi * 0.5 + 0.05, 34, 4, courtyard_pal, leaf_scale=0.62, leaf_density=0.9)

    # 3) Right-Side Golden Autumn Tree framing the Railway Bend
    autumn_pal = ["#6b2416", "#a83c1c", "#d66824", "#eb962f", "#f7c954"]
    build_organic_tree(3460, 1890, 275, math.pi * 0.5 + 0.12, 66, 5, autumn_pal, leaf_scale=0.95, leaf_density=0.95)

    # ==================================================================
    # 8. FOREGROUND CURVED GRASS TUFTS & WILDFLOWERS
    # ==================================================================
    for gi in range(180):
        gx = rng.uniform(25, VW - 25)
        gy = rng.uniform(1765, VH - 18)
        if 1580 < gx < 2520 and gy > 1800:
            continue
        gh = rng.uniform(36, 92)
        lean = rng.uniform(-24, 24)
        gtag = f"gr_{gi}"
        sketch.append(("line", [gx, gy, gx + lean * 0.5, gy - gh * 0.55, gx + lean, gy - gh],
                       {"fill": p_mid, "width": 1.2, "smooth": True}, gtag, "L_FG"))
        color.append(("recolor", gtag, {"fill": rng.choice(["#2a5425", "#386e2e", "#4d8a39", "#69a344"])}))

    flw_cols = ["#fff176", "#ff8a80", "#ffffff", "#ffd54f", "#ce93d8"]
    for fi in range(30):
        fx = rng.uniform(60, 1520) if fi < 18 else rng.uniform(2650, VW - 60)
        fy = rng.uniform(1830, VH - 60)
        ftag = f"flw_{fi}"
        sketch.append(("oval", [fx - 7, fy - 7, fx + 7, fy + 7], {"outline": p_mid, "width": 0.9}, ftag, "L_FG"))
        color.append(("recolor", ftag, {"fill": rng.choice(flw_cols), "outline": "#6e5c3e"}))

    # ==================================================================
    # 9. GRACEFUL SOARING BIRDS IN THE SKY
    # ==================================================================
    bird_spots = [
        (1140, 420, 42), (1235, 385, 34), (1310, 445, 28),
        (1820, 310, 36), (1910, 345, 26), (2790, 460, 32), (2875, 425, 24)
    ]
    for bi, (bx, by, bs) in enumerate(bird_spots):
        bpts = [bx - bs, by + bs * 0.12, bx - bs * 0.45, by - bs * 0.38, bx, by + bs * 0.05,
                bx + bs * 0.45, by - bs * 0.38, bx + bs, by + bs * 0.12]
        btag = f"bird_{bi}"
        sketch.append(("line", bpts, {"fill": p_dark, "width": 2.2, "smooth": True}, btag, "L_BIRD"))
        color.append(("recolor", btag, {"fill": "#26303d"}))

    return sketch, color, rail_samples


# ---------------- PAPER BACKDROP & ANIMATED GRAPHITE PENCIL ----------------
def draw_paper_backdrop():
    x1, y1 = to_scr(0, 0)
    x2, y2 = to_scr(VW, VH)
    cv.create_rectangle(x1 + 6, y1 + 6, x2 + 6, y2 + 6, fill="#0d0e12", outline="", tags=("paper_bg",))
    cv.create_rectangle(x1, y1, x2, y2, fill="#f7f2e8", outline="#d8ceb8", width=2, tags=("paper_sheet",))


def move_pencil(px, py):
    for pid in state["pencil_ids"]:
        cv.delete(pid)
    state["pencil_ids"].clear()
    tip = cv.create_polygon(px, py, px + 8, py - 14, px + 14, py - 8, fill="#2b2e33", outline="", tags=("pencil",))
    cone = cv.create_polygon(px + 8, py - 14, px + 18, py - 24, px + 24, py - 18, px + 14, py - 8,
                             fill="#e0b88a", outline="#8c6844", tags=("pencil",))
    body = cv.create_polygon(px + 18, py - 24, px + 58, py - 64, px + 64, py - 58, px + 24, py - 18,
                             fill="#e8b438", outline="#8a6518", tags=("pencil",))
    state["pencil_ids"].extend([body, cone, tip])


def hide_pencil():
    for pid in state["pencil_ids"]:
        cv.delete(pid)
    state["pencil_ids"].clear()


# ---------------- EXECUTION STEPS ----------------
def create_shape(shape_kind, coords, kwargs, tags):
    sc = cam["scale"]
    kw = dict(kwargs)
    if "width" in kw:
        kw["width"] = max(0.65, kw["width"] * sc * 2.15)
    spts = to_scr_pts(coords)
    if shape_kind == "line":
        return cv.create_line(*spts, tags=tags, **kw), spts
    elif shape_kind == "poly":
        return cv.create_polygon(*spts, tags=tags, **kw), spts
    elif shape_kind == "oval":
        return cv.create_oval(*spts, tags=tags, **kw), spts
    else:
        return cv.create_rectangle(*spts, tags=tags, **kw), spts


def run_sketch_op(op):
    kind, coords, kwargs, tag, layer_tag = op
    _, spts = create_shape(kind, coords, kwargs, (tag, layer_tag, "scene"))
    move_pencil(spts[-2], spts[-1])


def run_color_op(op):
    action = op[0]
    if action == "recolor":
        _, tag, kw = op
        cv.itemconfigure(tag, **kw)
    elif action == "insert_below":
        _, ref_tag, shape_kind, coords, kw, own_tag = op
        item, _ = create_shape(shape_kind, coords, kw, (own_tag, "scene"))
        refs = cv.find_withtag(ref_tag)
        if refs:
            cv.tag_lower(item, refs[0])
    elif action == "insert_above":
        _, ref_tag, shape_kind, coords, kw, own_tag = op
        item, _ = create_shape(shape_kind, coords, kw, (own_tag, "scene"))
        refs = cv.find_withtag(ref_tag)
        if refs:
            cv.tag_raise(item, refs[-1])


def draw_signature():
    for sid in state["sig_ids"]:
        cv.delete(sid)
    state["sig_ids"].clear()

    partial = SIGNATURE_TEXT[:state["sig_idx"]]
    bx1, by1 = to_scr(2150, VH - 165)
    bx2, by2 = to_scr(3760, VH - 36)
    tx, ty = to_scr(2955, VH - 100)
    fsize = max(11, int(52 * cam["scale"]))

    plaque = cv.create_rectangle(bx1, by1, bx2, by2, fill="#f7f1e3", outline="#6e5a44",
                                 width=max(1, int(2.2 * cam["scale"])), tags=("sig",))
    txt_sh = cv.create_text(tx + 1.5, ty + 1.5, text=partial, fill="#d4c5ab",
                            font=("Georgia", fsize, "bold italic"), tags=("sig",))
    txt = cv.create_text(tx, ty, text=partial, fill="#241c14",
                         font=("Georgia", fsize, "bold italic"), tags=("sig",))
    state["sig_ids"].extend([plaque, txt_sh, txt])


def sample_rail(t):
    samples = state["rail_curve"]
    n = len(samples) - 1
    t = max(0.0, min(1.0, t))
    fi = t * n
    i0 = min(n - 1, int(fi))
    frac = fi - i0
    s0, s1 = samples[i0], samples[i0 + 1]
    x = s0[1] + (s1[1] - s0[1]) * frac
    y = s0[2] + (s1[2] - s0[2]) * frac
    nx = s0[3] + (s1[3] - s0[3]) * frac
    ny = s0[4] + (s1[4] - s0[4]) * frac
    persp = s0[5] + (s1[5] - s0[5]) * frac
    return x, y, nx, ny, persp


def init_live_world():
    live = state["live"]
    live["birds"] = [
        [random.uniform(300, 3500), random.uniform(220, 620), random.uniform(2.5, 4.8), random.uniform(0, 6.28), random.uniform(26, 44), None]
        for _ in range(7)
    ]
    live["leaves"] = [
        [random.uniform(200, 950), random.uniform(900, 1450), random.uniform(1.2, 2.2), random.uniform(0, 6.28),
         random.choice(["#64a13d", "#94bf4e", "#eb962f", "#f7c954"]), None]
        for _ in range(8)
    ]
    live["smoke"] = []
    live["train_smoke"] = []
    live["train_t"] = 0.0


def update_live_train():
    """Glides a miniature scenic passenger train out of the tunnel along the 3D perspective railway line!"""
    live = state["live"]
    for tid in live["train_ids"]:
        cv.delete(tid)
    live["train_ids"].clear()

    live["train_t"] += 0.0042
    if live["train_t"] > 1.28:
        live["train_t"] = -0.04

    car_offsets = [-0.21, -0.15, -0.09, -0.03, 0.025]
    for ci, off in enumerate(car_offsets):
        ct = live["train_t"] + off
        if ct < 0.01 or ct > 1.03:
            continue
        x, y, nx, ny, p = sample_rail(ct)
        x2, y2, _, _, _ = sample_rail(min(1.0, ct + 0.025))
        dx, dy = x2 - x, y2 - y
        mag = max(1e-5, math.hypot(dx, dy))
        fx, fy = dx / mag, dy / mag

        half_l = 42.0 * p
        half_w = 24.0 * p
        h_car = 44.0 * p
        is_loco = (ci == len(car_offsets) - 1)

        c1 = (x - fx * half_l - nx * half_w, y - fy * half_l - ny * half_w)
        c2 = (x + fx * half_l - nx * half_w, y + fy * half_l - ny * half_w)
        c3 = (x + fx * half_l + nx * half_w, y + fy * half_l + ny * half_w)
        c4 = (x - fx * half_l + nx * half_w, y - fy * half_l + ny * half_w)
        top_pts = [c1[0], c1[1] - h_car, c2[0], c2[1] - h_car, c3[0], c3[1] - h_car, c4[0], c4[1] - h_car]
        side_pts = [c1[0], c1[1], c2[0], c2[1], c2[0], c2[1] - h_car, c1[0], c1[1] - h_car]
        front_pts = [c2[0], c2[1], c3[0], c3[1], c3[0], c3[1] - h_car, c2[0], c2[1] - h_car]

        body_col = "#243447" if is_loco else "#2c5f8a"
        roof_col = "#c94c38" if is_loco else "#d9e1e8"

        s_id = cv.create_polygon(*to_scr_pts(side_pts), fill=body_col, outline="#141d26", tags=("live_train",))
        f_id = cv.create_polygon(*to_scr_pts(front_pts), fill=lerp_hex(body_col, "#ffffff", 0.18), outline="#141d26", tags=("live_train",))
        r_id = cv.create_polygon(*to_scr_pts(top_pts), fill=roof_col, outline="#141d26", tags=("live_train",))
        live["train_ids"].extend([s_id, f_id, r_id])

        if is_loco:
            hx, hy = to_scr((c2[0] + c3[0]) * 0.5, (c2[1] + c3[1]) * 0.5 - h_car * 0.45)
            hr = max(2.0, 7.0 * p * cam["scale"])
            hl = cv.create_oval(hx - hr, hy - hr, hx + hr, hy + hr, fill="#fff59d", outline="#f2c14e", tags=("live_train",))
            live["train_ids"].append(hl)
            if random.random() < 0.45:
                live["train_smoke"].append([x, y - h_car * 1.15, 10.0 * p, 1.0, None])
        else:
            wx1, wy1 = to_scr(c1[0] + (c2[0] - c1[0]) * 0.25, c1[1] + (c2[1] - c1[1]) * 0.25 - h_car * 0.52)
            wx2, wy2 = to_scr(c1[0] + (c2[0] - c1[0]) * 0.78, c1[1] + (c2[1] - c1[1]) * 0.78 - h_car * 0.52)
            wl = cv.create_line(wx1, wy1, wx2, wy2, fill="#ffe899", width=max(1.2, 6.0 * p * cam["scale"]), dash=(4, 3), tags=("live_train",))
            live["train_ids"].append(wl)

    for sm in live["train_smoke"][:]:
        sm[0] += random.uniform(-2.0, 2.5)
        sm[1] -= random.uniform(3.0, 5.5)
        sm[2] += 1.6
        sm[3] -= 0.035
        if sm[3] <= 0.05:
            if sm[4] is not None:
                cv.delete(sm[4])
            live["train_smoke"].remove(sm)
            continue
        x1, y1 = to_scr(sm[0] - sm[2], sm[1] - sm[2])
        x2, y2 = to_scr(sm[0] + sm[2], sm[1] + sm[2])
        col = lerp_hex("#cbdae6", "#ffffff", sm[3])
        if sm[4] is None:
            sm[4] = cv.create_oval(x1, y1, x2, y2, fill=col, outline="", tags=("live_smoke",))
        else:
            cv.coords(sm[4], x1, y1, x2, y2)
            cv.itemconfigure(sm[4], fill=col)


# ---------------- MAIN ANIMATION LOOP ----------------
def tick():
    if paused[0]:
        root.after(60, tick)
        return

    _, s_batch, c_batch, delay_ms = SPEED_PRESETS[speed_idx[0]]

    if state["phase"] == "SKETCH":
        ops = state["sketch_ops"]
        for _ in range(s_batch):
            if state["sketch_idx"] < len(ops):
                run_sketch_op(ops[state["sketch_idx"]])
                state["sketch_idx"] += 1
            else:
                hide_pencil()
                state["phase"] = "COLORIZE"
                phase_lbl.config(text="STEP 2/3: WATERCOLOR SHADING & COLORIZING...", fg="#7ce0ff")
                break
        pct = (state["sketch_idx"] / max(1, len(ops))) * 100.0
        prog_lbl.config(text=f"{pct:05.1f}% | SKETCH ({state['sketch_idx']}/{len(ops)})")
        root.after(delay_ms, tick)

    elif state["phase"] == "COLORIZE":
        ops = state["color_ops"]
        for _ in range(c_batch):
            if state["color_idx"] < len(ops):
                run_color_op(ops[state["color_idx"]])
                state["color_idx"] += 1
            else:
                state["phase"] = "SIGNATURE"
                state["sig_idx"] = 0
                phase_lbl.config(text="STEP 3/3: SIGNING ARTWORK...", fg="#f3d082")
                break
        pct = (state["color_idx"] / max(1, len(ops))) * 100.0
        if state["phase"] == "COLORIZE":
            prog_lbl.config(text=f"{pct:05.1f}% | COLOR ({state['color_idx']}/{len(ops)})")
        root.after(delay_ms, tick)

    elif state["phase"] == "SIGNATURE":
        state["sig_idx"] += 1
        draw_signature()
        if state["sig_idx"] >= len(SIGNATURE_TEXT):
            state["phase"] = "LIVE"
            phase_lbl.config(text="COMPLETE! LIVE TRAIN & BIRDS ACTIVE — ZOOM TO INSPECT LEAVES!", fg="#8be0a4")
            prog_lbl.config(text="100.0% | 4K READY")
            init_live_world()
            root.after(40, tick)
        else:
            root.after(75, tick)

    elif state["phase"] == "LIVE":
        live = state["live"]
        for b in live["birds"]:
            b[0] = (b[0] + b[2]) % (VW + 200)
            b[3] += 0.22
            flap = math.sin(b[3]) * (b[4] * 0.38)
            bs = b[4]
            pts = to_scr_pts([b[0] - bs, b[1] + flap, b[0] - bs * 0.45, b[1] - abs(flap) - 6,
                              b[0], b[1], b[0] + bs * 0.45, b[1] - abs(flap) - 6, b[0] + bs, b[1] + flap])
            if b[5] is None:
                b[5] = cv.create_line(*pts, fill="#222a33", width=2, smooth=True, tags=("live",))
            else:
                cv.coords(b[5], *pts)

        if random.random() < 0.16:
            live["smoke"].append([1158, 1335, 12.0, 1.0, None])
        for sm in live["smoke"][:]:
            sm[0] += random.uniform(1.0, 2.6)
            sm[1] -= random.uniform(2.2, 4.0)
            sm[2] += 1.2
            sm[3] -= 0.024
            if sm[3] <= 0.05:
                if sm[4] is not None:
                    cv.delete(sm[4])
                live["smoke"].remove(sm)
                continue
            x1, y1 = to_scr(sm[0] - sm[2], sm[1] - sm[2])
            x2, y2 = to_scr(sm[0] + sm[2], sm[1] + sm[2])
            col = lerp_hex("#d8e3ec", "#ffffff", sm[3])
            if sm[4] is None:
                sm[4] = cv.create_oval(x1, y1, x2, y2, fill="", outline=col, width=1.4, tags=("live",))
            else:
                cv.coords(sm[4], x1, y1, x2, y2)
                cv.itemconfigure(sm[4], outline=col)

        for lf in live["leaves"]:
            lf[3] += 0.07
            lf[0] += math.sin(lf[3]) * 3.0 + 1.1
            lf[1] += lf[2] * 1.9
            if lf[1] > VH - 80:
                lf[0], lf[1] = random.uniform(220, 920), random.uniform(900, 1320)
            lpts, _, _, _ = make_leaf_geometry(lf[0], lf[1], 36, 16, lf[3])
            sp = to_scr_pts(lpts)
            if lf[5] is None:
                lf[5] = cv.create_polygon(*sp, fill=lf[4], outline="#23361c", tags=("live",))
            else:
                cv.coords(lf[5], *sp)

        update_live_train()
        # Keep foreground trees & signature above the passing train!
        cv.tag_raise("L_TREE")
        cv.tag_raise("L_FG")
        cv.tag_raise("sig")
        root.after(34, tick)


# ---------------- RESPONSIVE RESIZE, ZOOM & PAN ----------------
drag_pt = [None, None]


def apply_camera_delta(old_scale, old_ox, old_oy):
    if old_scale <= 0:
        return
    ratio = cam["scale"] / old_scale
    cv.move("all", -old_ox, -old_oy)
    cv.scale("all", 0, 0, ratio, ratio)
    cv.move("all", cam["ox"], cam["oy"])
    if state["phase"] in ("SIGNATURE", "LIVE"):
        draw_signature()


def on_resize(e):
    old_s, old_ox, old_oy = cam["scale"], cam["ox"], cam["oy"]
    cam["vw_px"], cam["vh_px"] = e.width, e.height
    recompute_transform()
    apply_camera_delta(old_s, old_ox, old_oy)


def zoom_at(mx, my, factor):
    nz = cam["user_zoom"] * factor
    if nz < 0.85 or nz > 10.0:
        return
    old_s, old_ox, old_oy = cam["scale"], cam["ox"], cam["oy"]
    vx = (mx - old_ox) / old_s
    vy = (my - old_oy) / old_s
    cam["user_zoom"] = nz
    recompute_transform()
    nx, ny = to_scr(vx, vy)
    cam["pan_x"] += mx - nx
    cam["pan_y"] += my - ny
    recompute_transform()
    apply_camera_delta(old_s, old_ox, old_oy)


def reset_view():
    old_s, old_ox, old_oy = cam["scale"], cam["ox"], cam["oy"]
    cam["user_zoom"] = 1.0
    cam["pan_x"] = 0.0
    cam["pan_y"] = 0.0
    recompute_transform()
    apply_camera_delta(old_s, old_ox, old_oy)


def zoom_focus(vx, vy, z=5.0):
    reset_view()
    sx, sy = to_scr(vx, vy)
    zoom_at(sx, sy, z)


def cycle_speed():
    speed_idx[0] = (speed_idx[0] + 1) % len(SPEED_PRESETS)
    spd_btn.config(text=f"SPEED: {SPEED_PRESETS[speed_idx[0]][0]}")


def toggle_pause():
    paused[0] = not paused[0]
    pause_btn.config(text="RESUME" if paused[0] else "PAUSE")


def replay():
    cv.delete("all")
    cam["user_zoom"] = 1.0
    cam["pan_x"] = 0.0
    cam["pan_y"] = 0.0
    recompute_transform()
    draw_paper_backdrop()
    state["phase"] = "SKETCH"
    state["sketch_idx"] = 0
    state["color_idx"] = 0
    state["sig_idx"] = 0
    state["pencil_ids"].clear()
    state["sig_ids"].clear()
    state["live"] = {"birds": [], "smoke": [], "leaves": [], "train_t": 0.0, "train_ids": [], "train_smoke": []}
    phase_lbl.config(text="STEP 1/3: PENCIL SKETCHING ON PAPER...", fg="#f3d082")


cv.bind("<Configure>", on_resize)
cv.bind("<MouseWheel>", lambda e: zoom_at(e.x, e.y, 1.22 if e.delta > 0 else 0.82))
cv.bind("<Button-4>", lambda e: zoom_at(e.x, e.y, 1.22))
cv.bind("<Button-5>", lambda e: zoom_at(e.x, e.y, 0.82))
cv.bind("<Button-1>", lambda e: (drag_pt.__setitem__(0, e.x), drag_pt.__setitem__(1, e.y)))


def on_drag(e):
    if drag_pt[0] is not None:
        dx, dy = e.x - drag_pt[0], e.y - drag_pt[1]
        cam["pan_x"] += dx
        cam["pan_y"] += dy
        cam["ox"] += dx
        cam["oy"] += dy
        cv.move("all", dx, dy)
        drag_pt[0], drag_pt[1] = e.x, e.y


cv.bind("<B1-Motion>", on_drag)
root.bind("<F11>", lambda e: (state.__setitem__("fullscreen", not state["fullscreen"]),
                              root.attributes("-fullscreen", state["fullscreen"])))
root.bind("<Escape>", lambda e: (state.__setitem__("fullscreen", False), root.attributes("-fullscreen", False)))

b_kw = {"bg": "#212630", "fg": "#d7e3f4", "font": ("Consolas", 9, "bold"), "bd": 1, "relief": "solid", "padx": 7}
tk.Button(hud, text="REPLAY", command=replay, **b_kw).pack(side="right", padx=3, pady=5)
tk.Button(hud, text="FIT", command=reset_view, **b_kw).pack(side="right", padx=3, pady=5)
tk.Button(hud, text="ZOOM: RAIL", command=lambda: zoom_focus(2420, 1780, 3.2),
          bg="#2c241b", fg="#f3d082", font=("Consolas", 9, "bold"), bd=1, relief="solid", padx=7).pack(side="right", padx=3, pady=5)
tk.Button(hud, text="ZOOM: LEAF", command=lambda: zoom_focus(580, 1290, 5.2),
          bg="#183020", fg="#8be0a4", font=("Consolas", 9, "bold"), bd=1, relief="solid", padx=7).pack(side="right", padx=3, pady=5)
tk.Button(hud, text="+", command=lambda: zoom_at(cam["vw_px"] * 0.5, cam["vh_px"] * 0.5, 1.35), **b_kw).pack(side="right", padx=2, pady=5)
tk.Button(hud, text="-", command=lambda: zoom_at(cam["vw_px"] * 0.5, cam["vh_px"] * 0.5, 0.74), **b_kw).pack(side="right", padx=2, pady=5)
pause_btn = tk.Button(hud, text="PAUSE", command=toggle_pause, **b_kw)
pause_btn.pack(side="right", padx=3, pady=5)
spd_btn = tk.Button(hud, text="SPEED: NATURAL", command=cycle_speed,
                    bg="#1c2a3a", fg="#7ce0ff", font=("Consolas", 9, "bold"), bd=1, relief="solid", padx=7)
spd_btn.pack(side="right", padx=3, pady=5)

if __name__ == "__main__":
    recompute_transform()
    draw_paper_backdrop()
    s_ops, c_ops, rail_s = build_realistic_blueprint()
    state["sketch_ops"] = s_ops
    state["color_ops"] = c_ops
    state["rail_curve"] = rail_s
    tick()
    root.mainloop()
